# AI Hub Apps Regression Test Suite

- [Objective](#objective)
- [Implementation](#implementation)
- [Trigger Flow](#trigger-flow)
    - [Flow Input](#flow-input)
    - [Runtime Config](#runtime-config)
- [Regression Test Runner Flow](#regression-test-runner-flow)
    - [Application Config](#application-config)
    - [Flow Input](#flow-input-1)
    - [Sample Runtime Config used by the Regression Suite to run an APP](#sample-runtime-config-used-by-the-regression-suite-to-run-an-app)
- [Check Job Status And Send Email Flow](#check-job-status-and-send-email-flow)
    - [Flow Input](#flow-input-2)
    - [Sample Runtime Config used by Regression Suite to trigger an email](#sample-runtime-config-used-by-regression-suite-to-trigger-an-email)
- [Steps to Add New App to Regression Test Suite](#steps-to-add-new-app-to-regression-test-suite)
    - [Pre-Requisites](#pre-requisites)
    - [Steps to Add](#steps-to-add)
- [Steps to run individual apps in the Regression Test Suite](#steps-to-run-individual-apps-in-the-regression-test-suite)
    - [Individual App Regression Test with Email Integration](#individual-app-regression-test-with-email-integration)
    - [Individual App Regression Test without Email Integration](#individual-app-regression-test-without-email-integration)

## Recording:
Link: [zoom link](https://instabase.zoom.us/rec/share/7wDHHIeUPzHHfvl0-m4S5sylw7eOo_0wUaVhfUFdrfoVEXwXAemhm4LqncUS1kZT.Y74WF1iKWFI4TybW), Passcode: 64wj@=LF

## Objective

In the past, we have seen that because of the upgrades in the LLM model or platform, there has been an impact on the pre-built AIHub applications. Since there was no automated way to check if the accuracy for any of the AI Hub applications decreased, it was hard to manually test all of the applications and see if there was an impact on any of the applications due to which we were not able to maintain the quality for these applications on AIHub. To address this, we have developed a regression test suite, which is scheduled to run every week on [aihub-uat](https://aihub-uat.internal.instabase.com/) environment to proactively identify these issues and send the mail to common email group aihub-apps-alert@instabase.com containing the app owners so that these can be fixed.

## Implementation

The Regression Test Suite comprises three key processes:
1. Trigger Flow
2. Regression Test Runner Flow
3. Job Status Check and Send Email Flow

These processes operate weekly, orchestrated by a scheduler called the Public Apps Regression Suite. The scheduler runs every Monday at 10:00 AM IST and kickstarts the Trigger Flow.

## Trigger Flow

The trigger flow has two responsibilities:
1. To trigger the regression test runner flow asynchronously for each AI hub application specified in the main config file main_config.json
2. To trigger the job status check and send email flow, which checks for job statuses and 

The main configuration file includes a list of pairs that connect the name of an application (the name it's known by when deployed) with the configuration file specific to that application. In other words, it's a file that helps you match application names to their corresponding configuration files.

### Flow Input

**Dummy input folder**: [dummy_input](https://aihub-uat.internal.instabase.com/aihub-uat-internal/SolEng_workspace/fs/Instabase%20Drive/SolEng%20Regression%20Suite/flows/Trigger%20Flow%20v2/datasets/dummy_input/)

### Runtime Config

```json
{
  "ENV": "UAT",
  "MAIN_CONFIG_FILE": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/Public Apps Regression Test Configs/UAT_Regression_Test_Config.json",
  "TOKEN": "<AUTH_TOKEN>",
  "FLOW_PATH": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/flows/Regression Test Runner v2/regression_test_runner.ibflow",
  "DUMMY_FOLDER_PATH": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/flows/Regression Test Runner v2/datasets/dummy_input",
  "CHECK_STATUS_EMAIL_TRIGGER_FLOW": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/flows/Check Job Status and Trigger Email/check_job_status_and_trigger_email.ibflow",
  "ALERT_EMAIL_ID": [
    "<EMAIL_IDs>"
  ],
  "TESTS_SUMMARY_PATH": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/files"
}
```
This flow is run weekly using a scheduler
 
## Regression Test Runner Flow
The objective of regression test runner flow is:
1. Execute the application through the API to obtain results stored in JSON format.
2. Compare the output values with golden values to calculate accuracy metrics.
3. Compare these metrics with the one previously used for deploying the application in this environment.
4. Store the test summary in a summary file that is common for all apps

The application config file holds important information, such as the path to golden docs, the expected correct data (ground truth path), where to store performance metrics (out path), and the location of previously used metrics for deployment. Additionally, it includes details related to the allowed percentage of drop in accuracy and for how many fields, before considering the test as a failure. 

### Application Config
```json
{
  "INPUT_FILES_PATH": [str] <Path to the Test Files>,
  "OUT_FILES_PATH": [str] <Path where the output files to be dumped>,
  "GOLDEN_FILE_PATH": [str] <Path to the Goldens associated to the Test Files>,
  "GOLDEN_METRIC_PATH": [str] <Path to accuracy file which was baselined for App publishing>,
  "ACCURACY_DROP_ALLOWED": [int] <Field Level Validated Accuracy Threshold allowed to drop>,
  "ACCURACY_DROP_FIELDS_ALLOWED_COUNT": [int] <Number of fields allowed to drop the threshold validated accuracy>,
  "FIELDS_ACCURACY_DROP_ALLOWED":{
    [str] <Name of the field>: [int] <Field Level Validated Accuracy Threshold allowed to drop>,
  }
}
```
**Example:**
```json
{
  "INPUT_FILES_PATH": "ib-internal/SolEng_workspace/fs/Instabase Drive/aihub/21656903-7037-4e72-a3be-68cd3b072b19/project/flows/new_golden_samples",
  "OUT_FILES_PATH": "ib-internal/SolEng_workspace/fs/Instabase Drive/files",
  "GOLDEN_FILE_PATH": "ib-internal/SolEng_workspace/fs/Instabase Drive/aihub/21656903-7037-4e72-a3be-68cd3b072b19/project/flows/goldens/new_golden_samples-2024-07-16-08:21:31",
  "GOLDEN_METRIC_PATH": "ib-internal/SolEng_workspace/fs/Instabase Drive/aihub/21656903-7037-4e72-a3be-68cd3b072b19/project/flows/accuracy/new_golden_samples-2024-07-16-08:21:31-57fdbb6a-82f8-4fc4-80eb-8dd8e1225b9d-2024-07-16-09:47:34/metrics.json",
  "ACCURACY_DROP_ALLOWED": 6,
  "ACCURACY_DROP_FIELDS_ALLOWED_COUNT": 2,
  "FIELDS_ACCURACY_DROP_ALLOWED":{
    "Company_Name":2
  }
}
```

### Flow Input
**Dummy input folder:** [dummy_input](https://aihub-uat.internal.instabase.com/aihub-uat-internal/SolEng_workspace/fs/Instabase%20Drive/SolEng%20Regression%20Suite/flows/Regression%20Test%20Runner%20v2/datasets/dummy_input/)

### Sample Runtime Config used by the Regression Suite to run an APP
```json
{
  "ENV": "UAT",
  "TOKEN": "<AUTH_TOKEN>",
  "APP_NAME": "Passport",
  "APP_CONFIG_FILE": "aihub-uat-internal/SolEng_workspace/fs/Soleng S3 Drive/SolEng Regression Suite/Public Apps Regression Test Configs/Passport.json",
  "TESTS_SUMMARY_PATH": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/files/"
}
```
This flow is triggered by trigger flow per application

## Check Job Status And Send Email Flow

The objective of Check Job Status and Send Email Flow is:
1. For each app, poll the job status and get the test summary for the app from the summary file that is common for all apps
2. Once a summary is obtained for all apps, it sends the consolidated email to aihub-apps-alert@instabase.com Group

### Flow Input
**Dummy input folder:** [dummy_input](https://aihub-uat.internal.instabase.com/aihub-uat-internal/SolEng_workspace/fs/Instabase%20Drive/SolEng%20Regression%20Suite/flows/Check%20Job%20Status%20and%20Trigger%20Email/datasets/dummy_input/)

### Sample Runtime Config used by Regression Suite to trigger an email
```json
{
  "ENV": "UAT",
  "JOBS_TRIGGERED": "{app_name_job_id_map}"
  "TOKEN": "{ib_app_admin_token}",
  "TESTS_SUMMARY_PATH": "{tests_summary_path}"
  "ALERT_EMAIL_ID": "aihub-apps-alert@instabase.com"
}
```

## Steps to Add New App to Regression Test Suite

### Pre-Requisites
- If the Application is developed in a Non-UAT environment ensure the Build Project is migrated from Non-UAT to UAT using the [CI/CD Pipeline](https://instabase.atlassian.net/wiki/spaces/AE/pages/2627567627)
- Test Data required for the regression suite is also migrated. The below list is considered as the test data:
    - Ground Truth Samples
    - Ground Truth
    - Benchmarked Accuracy
- Application is giving consistent results (i.e. Validated Accuracy >= 90% across multiple runs)
- Application and the test data are migrated to the SolEng_workspace in the UAT environment

### Steps to Add
- Use the AIHub UAT Org Admin account ([1Password](https://start.1password.com/open/i?a=VAAEGM2JPRH27E45XRQMXG5UKA&v=r755rge3ipuxqvj2xweuahb4vi&i=gvtupzze4huhx3zay7pujf73ce&h=team-instabase.1password.com)) to login to the UAT environment
- Add an application-specific configuration file (JSON) to the configs [folder](https://aihub-uat.internal.instabase.com/aihub-uat-internal/SolEng_workspace/fs/Soleng%20S3%20Drive/SolEng%20Regression%20Suite/Public%20Apps%20Regression%20Test%20Configs/)
- `INPUT_FILES_PATH`: Samples that need to be used for the regression run. Usually, these will be the Ground Truth Samples.
- `OUT_FILES_PATH`: Path where the application run output needs to be stored. It is recommended to always keep this as constant: `"aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/files"`
- `GOLDEN_FILE_PATH`: Path where the Ground Truth of the application is present. Usually, the ground truth data is used for accuracy calculation.
- `GOLDEN_METRIC_PATH`: Path where the application's Benchmarked Accuracy’s metrics.json file is present. It is 1 of the accuracy results obtained from the multiple consistent runs where the validated accuracy is >= 90%.
- `ACCURACY_DROP_ALLOWED`: Accepted Validated Accuracy drop at the field level. It is recommended to allow up to 6% drop at the field level.
- `ACCURACY_DROP_FIELDS_ALLOWED_COUNT`: Accepted number of fields that can drop the validated accuracy configured in the Accuracy_Drop_Allowed field. It is recommended to allow up to 2 fields to drop the Validated Accuracy above the threshold configured.
- `FIELDS_ACCURACY_DROP_ALLOWED`: Map of Accepted Validated Accuracy drop at the field level

    **Example Config**: [Example App Specific Config](https://instabase.atlassian.net/wiki/spaces/AE/pages/2139717650/AI+Hub+Applications+Regression+Test+Suite#Example%3A)

- Update the main configuration (main_config.json) to include the new app as part of the regression test suite

**Note**:
- The Name of the application used during App Publishing / Deployment should be used as the key for the main_config.json file
- Whenever a new version of an application is deployed, update the GOLDEN_METRIC_PATH in the application's configuration with the most recent metrics generated path for that specific version of the application.

## Steps to run individual apps in the Regression Test Suite
### Individual App Regression Test with Email Integration

- Create a dummy main_config file which contains the information about the Application to be tested.
    
    Example:
    ```json
    {
    "Passport": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/Public Apps Regression Test Configs/Passport.json"
    }
    ```
- Trigger the [Trigger Flow Binary](https://aihub-uat.internal.instabase.com/aihub-uat-internal/SolEng_workspace/fs/Instabase%20Drive/SolEng%20Regression%20Suite/flows/Trigger%20Flow%20v2/trigger_flow.ibflowbin) with the following Runtime Configurations:
    ```json
    {
        "ENV": "UAT",
        "MAIN_CONFIG_FILE": <Path to newly created main_config.json file>,
        "TOKEN": <AUTH_TOKEN of AIHUB UAT ORG ADMIN>,
        "FLOW_PATH": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/flows/Regression Test Runner v2/regression_test_runner.ibflow",
        "DUMMY_FOLDER_PATH": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/flows/Regression Test Runner v2/datasets/dummy_input",
        "CHECK_STATUS_EMAIL_TRIGGER_FLOW": "aihub-uat-internal/SolEng_workspace/fs/Instabase Drive/SolEng Regression Suite/flows/Check Job Status and Trigger Email/check_job_status_and_trigger_email.ibflow",
        "ALERT_EMAIL_ID": [
            <EMAIL_ID TO BE ALERTED>
        ]
    }
    ```
### Individual App Regression Test without Email Integration

- Trigger the [Regression Test Flow](https://aihub-uat.internal.instabase.com/apps/flow/edit/aihub-uat-internal/SolEng_workspace/fs/Instabase%20Drive/SolEng%20Regression%20Suite/flows/Regression%20Test%20Runner%20v2/regression_test_runner.ibflow?) with the following Runtime configurations:
    ```json
    {
        "ENV": "UAT",
        "APP_NAME": <APP NAME>,
        "APP_CONFIG_FILE": <APP_SPECIFIC CONFIG FILE PATH>,
        "TOKEN": <AUTH_TOKEN of AIHUB UAT ORG ADMIN>,
        "TESTS_SUMMARY_PATH": <PATH WHERE APP RUN SUMMARY HAS TO BE STORED>
    }
    ```
