## NOTE: Keep in sync with instabase/utils/path/strutils.py
import os

try:
    from typing import Text, Tuple
except Exception as e:
    pass

_FILE_SEP = '/'
_VALID_TYPES = frozenset(['fs', 'databases'])


class IBCompletePath(object):
    """
    Complete path is :
      {repo_owner}/{repo_name}/{fs|databases}/{mount_point}/{path}
    or
      {repo_owner}/{repo_name}/{fs|databases}/{mount_point}
    or
      {repo_owner}/{repo_name}/{fs|databases}
  """

    def __init__(self, complete_path):
        # type: (Text) -> None
        if complete_path is None:
            raise IOError(u'Invalid CompletePath, it is an empty value')

        complete_path = complete_path.strip().strip('/')
        self.entire_path = complete_path
        self.parts = complete_path.split('/', 4)
        if len(self.parts) < 3:
            raise IOError(u'Invalid CompletePath ' + complete_path)

        self._mount_point = u''
        if len(self.parts) >= 4:
            self._mount_point = self.parts[3]

        self.relative_path = u''
        if len(self.parts) == 5:
            self.relative_path = self.parts[4]

        if self.type not in _VALID_TYPES:
            raise IOError(u'{} is not a valid TYPE for a complete path'.format(
                self.type))

    @property
    def repo_owner(self):
        # type: () -> Text
        return self.parts[0]

    @property
    def repo_name(self):
        # type: () -> Text
        return self.parts[1]

    @property
    def type(self):
        # type: () -> Text
        return self.parts[2]

    @property
    def mount_point(self):
        # type: () -> Text
        return self._mount_point

    @property
    def path(self):
        # type: () -> Text
        return self.relative_path

    @property
    def complete_path(self):
        # type: () -> Text
        return self.entire_path

    @property
    def full_mount_path(self):
        # type: () -> Text
        return u'/'.join(
            [self.repo_owner, self.repo_name, self.type, self.mount_point])

    @staticmethod
    def build(complete_path):
        # type: (Text) -> Tuple[IBCompletePath, Text]
        try:
            return IBCompletePath(complete_path), None
        except IOError as e:
            return None, u'{}'.format(e)


def split_file(path):
    # type: (Text) -> Tuple[Text, Text]
    els = path.rsplit('/', 1)
    if len(els) == 1:
        # This file is at the root dir.
        return u'', path
    dir_name, basename = els[0], els[1]
    return dir_name, basename


def get_ext(path):
    # type: (Text) -> Text
    parts = path.rsplit('.', 1)
    return parts[1] if len(parts) == 2 else u''


def strip_ext(path):
    # type: (Text) -> Text
    ext = get_ext(path)
    if not ext:
        return path
    return path[:-(len(ext) + 1)]


def join(part0, part1):
    # type: (Text, Text) -> Text
    part0 = part0.strip().strip(_FILE_SEP)
    part1 = part1.strip().strip(_FILE_SEP)
    return (part0 + _FILE_SEP + part1).strip().strip(_FILE_SEP)


def to_abs_path(s):
    # type: (Text) -> Text
    if s is None:
        return None
    return u'/' + s.lstrip('/')


def get_abs_path(cwd, path):
    # type: (Text, Text) -> Text
    p = path.strip()
    if p.startswith('/'):
        return os.path.normpath(p)

    return os.path.normpath(u'{0}/{1}'.format(cwd, p))
