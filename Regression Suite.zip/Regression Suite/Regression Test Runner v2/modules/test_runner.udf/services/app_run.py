import logging

import requests
import time
import json

from ..model import constants
import urllib.parse


class APPRun:

    def __init__(self, app_name: str, token: str, ib_input_path: str,
                 out_path: str, clients, summary_dict: dict, api_base_url: str,
                 app_owner: str):
        self.__app_name = app_name
        self.__token = token
        self.__ib_input_path = ib_input_path
        self.__out_path = out_path
        self.__api_base_url = api_base_url
        self.__clients = clients
        self.__summary_dict = summary_dict
        self.__app_owner = app_owner

    def run_app(self):
        logging.info('Running App')
        headers = self.__get_headers()
        run_app_payload = json.dumps({
            "input_dir": self.__ib_input_path,
            "name": self.__app_name,
            "owner": self.__app_owner,
            "settings": {
                "tags": [
                    f"{self.__app_name}", "SOL_ENG", "REGRESSION_SUITE_RUN"
                ]
            }
        })

        url = constants.APP_RUN_API.format(API_BASE_URL=self.__api_base_url)
        logging.info(
            f"url - {url} | headers - {headers} | run_app_payload - {run_app_payload}"
        )
        run_app_resp = requests.post(url, headers=headers, data=run_app_payload)
        logging.info(f"run_app_resp - {run_app_resp.__dict__}")

        job_id = run_app_resp.json().get('job_id')
        # job_id = run_app_resp.json().get('id')
        self.__summary_dict[
            'Application_Run_Job_ID'] = job_id if job_id else run_app_resp.text
        logging.info(f'App Running: {job_id}')
        return job_id
        # return self.__download_results(job_id)

    def download_results(self, job_id):

        if not job_id:
            raise Exception('No jobid found')
        # Using the Job ID from the app run get the current status. If complete,
        output_folder_path, _ = self.check_job_status(job_id)
        # return f'{output_folder_path}/batch.ibflowresults'
        logging.info('Downloading Results')
        results_payload = json.dumps({
            "file_offset": 0,
            "ibresults_path": f'{output_folder_path}/batch.ibflowresults',
            "options": {
                "include_checkpoint_results": True
            }
        })

        url = constants.RESULTS_API.format(API_BASE_URL=self.__api_base_url)
        results_resp = requests.post(url,
                                     headers=self.__get_headers(),
                                     data=results_payload)
        logging.info(results_resp.text)
        resp_data = results_resp.json()

        all_records = resp_data
        while len(resp_data.get('records', [])) > 0:
            next_file_offset = resp_data['records'][-1]['file_index'] + 1
            json_data = json.dumps({
                "file_offset": next_file_offset,
                "ibresults_path": f"{output_folder_path}/batch.ibflowresults",
                "options": {
                    "include_checkpoint_results": True
                }
            })

            r = requests.post(url, data=json_data, headers=self.__get_headers())
            resp_data = r.json()
            all_records['records'].extend(resp_data.get('records', []))
        with self.__clients.ibfile.open(
                self.__out_path + 'ibflowresults_resp.json', 'w') as f:
            f.write(json.dumps(all_records, indent=4))
        self.__summary_dict['IB_Flow_Results_JSON_URL'] = urllib.parse.quote(
            self.__api_base_url + '/' + self.__out_path +
            'ibflowresults_resp.json',
            safe='/:?=&')
        return all_records

    def check_job_status(self, job_id):
        url = constants.FLOW_JOB_STATUS_API.format(
            API_BASE_URL=self.__api_base_url, job_id=job_id)
        job_status = ''
        while job_status != 'DONE':
            job_status_resp = requests.get(url, headers=self.__get_headers())
            logging.info(f"Job Status Resp Content: {job_status_resp.content}")
            try:
                job_status = job_status_resp.json().get('state')
                logging.info(f'Job Status: {job_status}')
                time.sleep(5)
            except:
                job_status = "Error"
                logging.info(f"Job Status: Unable to fetch job status")
                time.sleep(30)

        # Now the job is complete, get the results
        output_folder_path = job_status_resp.json(
        )['results'][0]['output_folder']
        current_review_id = json.loads(
            job_status_resp.json().get("cur_status")).get("job_id")
        solution_id = json.loads(job_status_resp.json().get("cur_status")).get(
            "deployed_solution_id")
        self.__summary_dict["App_UUID"] = solution_id
        return output_folder_path, current_review_id

    def continue_run(self, job_id):
        if not job_id:
            raise Exception('No jobid found')

        logging.info(f'Checking status of job with ID: {job_id}')
        output_folder_path, current_review_id = self.check_job_status(job_id)

        logging.info(f'Continuing job with ID: {current_review_id}')
        url = f"{self.__api_base_url}/api/v1/jobs/retry?job_id={current_review_id}"
        headers = self.__get_headers()
        continue_resp = requests.get(url, headers=headers)

        if continue_resp.status_code == 200:
            logging.info(f'Job {job_id} continued successfully.')
        else:
            logging.error(
                f'Failed to continue job {job_id}. Response: {continue_resp.text}'
            )

        return continue_resp.json()

    def __get_headers(self):
        API_HEADERS = {
            'Authorization':
                f'Bearer {self.__token}',
            'IB-Context':
                f"aihub-uat-internal"
                if "aihub-uat" in self.__api_base_url else f'ib-internal'
        }
        return API_HEADERS
