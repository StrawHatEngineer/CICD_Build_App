import requests
import logging


# fetch the ground truth set from aihub
def fetch_ground_truth_set(url: str, ground_truth_id: int, token: str):
    full_url = f"{url}/api/v2/ground-truth-sets/{ground_truth_id}"
    headers = {'Authorization': f'Bearer {token}'}
    response = requests.get(full_url, headers=headers)
    logging.info(f"response : {response}, {response.json()}")
    if response.status_code == 200:
        return response.json()
    else:
        response.raise_for_status()


# get the app details from aihub
def get_app_details(api_base_url, deployed_solution_id, token):
    app_details_url = f"{api_base_url}/api/v2/solutions/deployed/{deployed_solution_id}"
    headers = {'Authorization': f'Bearer {token}'}
    app_details_resp = requests.get(app_details_url, headers=headers)
    app_details = app_details_resp.json().get('solution', {})
    app_name = app_details.get('name')
    app_owner = app_details.get('owner')
    return app_name, app_owner


# get the accuracy details from aihub
def get_accuracy_details(api_base_url, deployed_solution_id, accuracy_run_id,
                         token):
    if not accuracy_run_id:
        raise Exception('No accuracy run id found')

    app_name, app_owner = get_app_details(api_base_url, deployed_solution_id,
                                          token)

    url = f"{api_base_url}/api/v2/ground-truth-sets/accuracy-runs"
    params = {'app_name': app_name, 'app_owner': app_owner}
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
        'ib-context': 'ib-internal'
    }
    accuracy_resp = requests.get(url, headers=headers, params=params)
    logging.info(f"accuracy_resp - {accuracy_resp.__dict__}")

    accuracy_runs = accuracy_resp.json().get('accuracy_report_runs', [])
    for run in accuracy_runs:
        if run.get('id') == accuracy_run_id:
            return run
    raise Exception('Accuracy run id not found in the list of accuracy runs')
