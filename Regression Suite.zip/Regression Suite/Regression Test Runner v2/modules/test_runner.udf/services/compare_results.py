import json
import logging
from typing import Text
import urllib.parse
import os


def compare_field_metrics_and_store_results(
        metrics_path: Text,
        golden_metrics_path: Text,
        app_name: Text,
        out_path: Text,
        clients,
        accuracy_drop_allowed: int,
        accuracy_drop_fields_count_allowed: int,
        summary_dict: dict,
        api_base_url: str,
        note: str = ""):
    try:
        metrics_file_name = metrics_path.split('/')[-1]
        with clients.ibfile.open(metrics_path, 'r') as f:
            recent_metrics = json.load(f)

        with clients.ibfile.open(f'{golden_metrics_path}', 'r') as f:
            golden_metrics = json.load(f)

        classes_metric_info_recent = {
            cls["name"]: cls["field_metrics"]
            for cls in recent_metrics["classes"]
        }
        classes_metric_info_golden = {
            cls["name"]: cls["field_metrics"]
            for cls in golden_metrics["classes"]
        }

        result = dict()
        is_test_failed = False
        for cls, field_metrics in classes_metric_info_golden.items():
            result[cls] = dict()
            summary_dict[cls] = dict()

            fields = ['automation', 'automation_accuracy']
            accuracy_no_change_count = {}
            accuracy_increase_count = {}
            accuracy_drop_count = {}
            accuracy_drop_above_threshold = {}
            total_fields = {}
            accuracy_dropped_fields = {}

            for field in fields:
                accuracy_no_change_count[field] = 0
                accuracy_increase_count[field] = 0
                accuracy_drop_count[field] = 0
                accuracy_drop_above_threshold[field] = 0
                total_fields[field] = len(field_metrics.keys())
                accuracy_dropped_fields[field] = []

            for field_name in list(field_metrics.keys()):
                result[cls][field_name] = dict()
                for field in fields:
                    if field in field_metrics[field_name]:
                        golden_val = field_metrics[field_name][field]
                        recent_metric_val = classes_metric_info_recent.get(
                            cls, {}).get(field_name, {}).get(field, 0)
                        diff = recent_metric_val - golden_val
                        result[cls][field_name][field] = dict()
                        result[cls][field_name][field]['change'] = abs(diff)
                        result[cls][field_name][field][
                            'current_run_metric'] = recent_metric_val
                        result[cls][field_name][field][
                            'prev_run_metric'] = golden_val
                        if diff < 0:
                            result[cls][field_name][field][
                                'accuracy_status'] = 'Dropped'
                            accuracy_drop_count[field] += 1
                            if abs(diff) > accuracy_drop_allowed:
                                accuracy_drop_above_threshold[field] += 1
                                accuracy_dropped_fields[field].append(
                                    {field_name: f"{abs(diff):.2f}%"})
                        elif diff > 0:
                            accuracy_increase_count[field] += 1
                            result[cls][field_name][field][
                                'accuracy_status'] = 'Increased'
                        else:
                            accuracy_no_change_count[field] += 1
                            result[cls][field_name][field][
                                'accuracy_status'] = 'No Change'

            for field in fields:
                summary_dict[cls][field] = dict()
                summary_dict[cls][field]['Total_Fields'] = total_fields[field]
                summary_dict[cls][field][
                    'Total_Accuracy_No_Change_Field_Count'] = accuracy_no_change_count[
                        field]
                summary_dict[cls][field][
                    'Total_Accuracy_Increase_Field_Count'] = accuracy_increase_count[
                        field]
                summary_dict[cls][field][
                    'Total_Accuracy_Drop_Count'] = accuracy_drop_count[field]
                summary_dict[cls][field][
                    'Accuracy_Drop_Above_Threshold_Count'] = accuracy_drop_above_threshold[
                        field]
                if accuracy_drop_above_threshold[field] > abs(
                        accuracy_drop_fields_count_allowed):
                    logging.warning('Accuracy dropped for ' +
                                    str(accuracy_drop_above_threshold[field]) +
                                    ' which is above the allowed threshold: ' +
                                    str(accuracy_drop_fields_count_allowed))
                    is_test_failed = True

        out_path = os.path.join(out_path, f'{app_name}_accuracy_deviation.json')
        with clients.ibfile.open(out_path, 'w') as f:
            f.write(json.dumps(result, indent=4))
        summary_dict['Accuracy_Deviation_URL'] = urllib.parse.quote(
            api_base_url + '/' + out_path, safe='/:?=&')
        summary_dict['Test_Status'] = "Failed" if is_test_failed else "Passed"
        summary_dict['Note'] = ""
        if is_test_failed:
            if accuracy_dropped_fields["automation"]:
                summary_dict[
                    'Note'] += f"Automation Rate dropped for the following fields: {json.dumps(accuracy_dropped_fields['automation'])}"
            if accuracy_dropped_fields["automation_accuracy"]:
                summary_dict[
                    'Note'] += rf"\n Validated Accuracy dropped for the following fields: {json.dumps(accuracy_dropped_fields['automation_accuracy'])}"
        # summary_dict['Note'] = f"Accuracy dropped for the following fields: {json.dumps(accuracy_dropped_fields)}" if is_test_failed else ""
        logging.info('Successfully calculated accuracy deviation for app: ' +
                     app_name)
    except:
        summary_dict['Test_Status'] = "Failed"
        summary_dict['Note'] = note
