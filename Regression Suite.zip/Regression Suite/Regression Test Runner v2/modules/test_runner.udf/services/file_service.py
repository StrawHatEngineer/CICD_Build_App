import json
import logging
from http.client import HTTPException

from ..model import constants
from ..model.request_params import RequestParams
from .request import HttpRequest


# Instead of using api calls need to use clients.ibfile
class FileService():

    def __init__(self, access_token: str, api_base_url: str):
        self.__http_request = HttpRequest()
        self.__access_token = access_token
        self.__api_base_url = api_base_url

    def check_path_exists(self, path: str, path_type="dir"):
        try:
            self.__validation_path_not_empty(path)
            url = self.__build_file_url(path)
            # payload = {
            #     "IB-Retry-Config": {
            #         "retries": 3,
            #         "backoff-seconds": 3
            #     }
            # }
            request_params = RequestParams(url=url,
                                           access_token="Bearer " +
                                           self.__access_token)
            response = self.__http_request.trigger_request(
                "HEAD", request_params)
            # print(response.text)
            if path_type == 'dir':
                # Check if the Content-Type header matches 'application/json'
                if response.headers.get('Content-Type',
                                        '') == 'application/json':
                    return True
            else:
                # Check if the Content-Type header matches 'application/octet-stream'
                if response.headers.get('Content-Type',
                                        '') == 'application/octet-stream':
                    return True
            return False
        except Exception as ex:
            logging.error(ex)
            return False

    def read_file(self, path: str, path_type="file"):
        try:
            self.__validation_path_not_empty(path)
            url = self.__build_file_url(path)
            params = {'expect-node-type': path_type}
            request_params = RequestParams(url=url,
                                           access_token="Bearer " +
                                           self.__access_token,
                                           params=params)
            response = self.__http_request.trigger_request(
                "GET", request_params)
            return response.content, None
        except Exception as ex:
            logging.error(ex)
            return None, ex

    def __build_file_url(self, path):
        url = constants.FILE_SERVICE_API.format(
            API_BASE_URL=self.__api_base_url)
        if url[-1] != '/':
            url += '/'
        if path[0] == '/':
            path = path[1:]
        url += path
        return url

    def __validation_path_not_empty(self, path):
        if not path:
            logging.error("Path is not provided")
            raise Exception("Path not present")
