import pandas as pd
import json
import numpy as np
import logging
import urllib.parse
import os


class DataAggregator:

    def __init__(self, merged_csv_path, merged_val_path, golden_path, clients,
                 out_path, summary_dict, API_BASE_URL):
        self.merged_csv = pd.read_csv(clients.ibfile.open(merged_csv_path))
        self.merged_val = pd.read_csv(clients.ibfile.open(merged_val_path))

        # Determine if the golden file is CSV or Excel
        logging.info(f"golden_path - {golden_path}")
        if golden_path.endswith('.csv'):
            self.golden_data = pd.read_csv(clients.ibfile.open(golden_path))
        elif golden_path.endswith(('.xls', '.xlsx')):
            self.golden_data = pd.read_excel(clients.ibfile.open(golden_path))
        else:
            raise ValueError("Unsupported file format for golden data")

        self.out_path = out_path
        self.clients = clients
        self.summary_dict = summary_dict
        self.API_BASE_URL = API_BASE_URL
        all_case_ids = pd.concat([
            self.merged_csv['Case ID'], self.merged_val['Case ID'],
            self.golden_data['Case ID']
        ]).unique()

        self.classes = {
            case_id: {
                "records": [],
                "fields": []
            } for case_id in all_case_ids
        }

    def process_records(self):
        for label in self.classes.keys():
            # Filter records for this class
            merged_class = self.merged_csv[self.merged_csv['Case ID'] == label]
            val_class = self.merged_val[self.merged_val['Case ID'] == label]
            golden_class = self.golden_data[self.golden_data['Case ID'] ==
                                            label]

            # Process each record in the class
            records = []
            for _, merged_row in merged_class.iterrows():
                case_id = merged_row['Case ID']

                # Find corresponding rows
                golden_row = golden_class[golden_class['Case ID'] ==
                                          case_id].iloc[0]
                val_row = val_class[val_class['Case ID'] == case_id].iloc[0]

                # Collect fields for the record
                fields = []
                for column in self.merged_csv.columns:
                    if column in ['Case ID']:
                        continue

                    extracted_value = merged_row[column]
                    golden_value = golden_row[column]
                    was_flagged = val_row[column] == 'TRUE'

                    fields.append({
                        "name": column,
                        "golden_value": str(golden_value),
                        "extracted_value": str(extracted_value),
                        "was_flagged_for_review": was_flagged
                    })

                # Determine if the entire record was flagged
                was_flagged_for_review = val_row.iloc[2:-1].eq('TRUE').any()

                records.append({
                    "name":
                        val_row['Case ID'],
                    "fields":
                        fields,
                    "was_classified_correctly":
                        True,
                    "was_flagged_for_review":
                        was_flagged_for_review,
                    "was_flagged_for_review_for_classification_checkpoint":
                        False,
                    "pages": []
                })

            self.classes[label]["records"] = records

    def aggregate_fields(self):
        for label in self.classes.keys():
            # Filter records for this class
            merged_class = self.merged_csv[self.merged_csv['Case ID'] == label]
            val_class = self.merged_val[self.merged_val['Case ID'] == label]
            golden_class = self.golden_data[self.golden_data['Case ID'] ==
                                            label]

            # Aggregate fields for the class
            aggregated_fields = []
            for column in self.merged_csv.columns:
                if column in ['Case ID']:
                    continue

                field_records = []
                for case_id in merged_class['Case ID']:
                    merged_row = merged_class[merged_class['Case ID'] ==
                                              case_id].iloc[0]
                    golden_row = golden_class[golden_class['Case ID'] ==
                                              case_id].iloc[0]
                    val_row = val_class[val_class['Case ID'] == case_id].iloc[0]

                    field_records.append({
                        "golden_value": str(golden_row[column]),
                        "extracted_value": str(merged_row[column]),
                        "was_flagged_for_review": val_row[column] == 'TRUE',
                        "name": val_row['Case ID']
                    })

                aggregated_fields.append({
                    "name": column,
                    "records": field_records
                })

            self.classes[label]["fields"] = aggregated_fields

    def get_raw_data_aggregated_output(self):
        self.process_records()
        self.aggregate_fields()
        output_json = {"classes": self.classes}
        logging.info(f"raw_data_aggregated_by_record_and_field: {output_json}")
        raw_data_path = f'{self.out_path}/raw_data_aggregated_by_record_and_field.json'
        with self.clients.ibfile.open(raw_data_path, 'w') as f:
            f.write(json.dumps(output_json, indent=4, default=str))
        self.summary_dict[
            'Extracted_And_Golden_Data_Aggregated_URL'] = urllib.parse.quote(
                self.API_BASE_URL + '/' + raw_data_path, safe='/:?=&')
        return output_json

    def generate_comparison_logic(self, merged_csv_path):
        labels = self.merged_csv['Case ID'].unique().tolist()

        output_json = {
            "comparisonStrategy": {},
            "classes": {},
            "exemptMisclassifiedRecords": False
        }

        for label in labels:
            fields = [
                col for col in self.merged_csv.columns
                if col not in ['Case ID']
            ]

            field_config = {
                "__model_result": {
                    "comparisonStrategy": {},
                    "type": "ANY",
                    "contentType": None
                }
            }

            for field in fields:
                field_config[field] = {
                    "comparisonStrategy": {},
                    "type": "TEXT",
                    "contentType": None
                }

            output_json["classes"][label] = {
                "comparisonStrategy": {},
                "fields": field_config
            }

        output_json["classes"]["Other"] = {
            "comparisonStrategy": {},
            "fields": {
                "__model_result": {
                    "comparisonStrategy": {},
                    "type": "ANY",
                    "contentType": None
                },
                "label": {
                    "comparisonStrategy": {},
                    "type": "TEXT",
                    "contentType": None
                }
            }
        }
        logging.info(f"Comparison Logic: {output_json}")
        return output_json
