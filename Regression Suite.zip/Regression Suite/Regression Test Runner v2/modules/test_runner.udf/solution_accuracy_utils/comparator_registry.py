from dateutil import parser
from mypy_extensions import TypedDict
from typing import Callable, Dict, List, Text, Tuple, Union, Any
import math
import numbers
from polyleven import levenshtein as lev
import string

from .consts import FLOAT, INT, TEXT


# Text comparators
def ignore_chars(
    golden_value: Text,
    extracted_value: Text,
    whitespace: bool = False,
    special: bool = False
) -> Union[Tuple[bool, Text], Tuple[Tuple[Text, Text], Text]]:
    if None in [golden_value, extracted_value]:
        return False, None

    for arg_name, arg_value, arg_type in [('whitespace', whitespace, bool),
                                          ('punctuation', special, bool)]:
        if not isinstance(arg_value, arg_type):
            return False, 'ignore_chars arg {} was not a {} as expected'.format(
                arg_name, arg_type.__name__)

    if whitespace:
        golden_value = "".join(golden_value.split())
        extracted_value = "".join(extracted_value.split())
    if special:
        for character in string.punctuation:
            golden_value = golden_value.replace(character, '')
            extracted_value = extracted_value.replace(character, '')
    return (golden_value, extracted_value), None


def date_string(golden_value: Text, extracted_value: Text) -> Tuple[bool, Text]:
    try:
        golden_date = parser.parse(golden_value)
        extracted_date = parser.parse(extracted_value)
        return golden_date == extracted_date, None
    except Exception:
        return False, None


def levenshtein(golden_value: Text,
                extracted_value: Text,
                max_distance: int = 0) -> Tuple[bool, Text]:
    if not isinstance(max_distance, numbers.Number):
        return False, 'levenshtein arg max_distance was not a number as expected'
    try:
        distance = lev(golden_value, extracted_value, max_distance)
        return distance <= max_distance, None
    except Exception:
        return False, None


def case_insensitive(
    golden_value: Text, extracted_value: Text
) -> Union[Tuple[bool, Text], Tuple[Tuple[Text, Text], Text]]:
    try:
        return (golden_value.casefold(), extracted_value.casefold()), None
    except Exception:
        return False, None


# Int comparators
def allow_max_diff_for_ints(golden_value: int,
                            extracted_value: int,
                            max_difference: int = 0) -> Tuple[bool, Text]:
    if None in [golden_value, extracted_value]:
        return False, None
    if not isinstance(max_difference, numbers.Number):
        return False, 'allow_max_diff_for_ints arg max_difference was not a number as expected'
    return abs(golden_value - extracted_value) <= max_difference, None


# Float comparators
def allow_max_diff_for_floats(golden_value: float,
                              extracted_value: float,
                              max_difference: float = 0.0) -> Tuple[bool, Text]:
    if None in [golden_value, extracted_value]:
        return False, None
    if not isinstance(max_difference, numbers.Number):
        return False, 'allow_max_diff_for_floats arg max_difference was not a number as expected'
    return abs(golden_value - extracted_value) <= max_difference, None


def round_float(
    golden_value: float,
    extracted_value: float,
    round_type: Text,
) -> Tuple[bool, Text]:
    if None in [golden_value, extracted_value]:
        return False, None
    for arg_name, arg_value, arg_type in [('round_type', round_type, Text)]:
        if not isinstance(arg_value, arg_type):
            return False, 'round_float arg {} was not a {} as expected'.format(
                arg_name, arg_type.__name__)
    is_match = False

    if round_type == 'nearest_int':
        is_match = is_match or round(golden_value) == round(extracted_value)
    if round_type == 'floor':
        is_match = is_match or math.floor(golden_value) == math.floor(
            extracted_value)
    if round_type == 'ceil':
        is_match = is_match or math.ceil(golden_value) == math.ceil(
            extracted_value)
    return is_match, None


# Parsers
# int parsers
def parse_european_format_for_ints(
    golden_value: Text, extracted_value: Text) -> Tuple[int, int, Text]:
  try:
    golden_numeric: Any = None
    extracted_numeric: Any = None
    if golden_value is not None and golden_value != '':
      golden_numeric = int(golden_value.replace(".", "").replace(",", "."))
    if extracted_value is not None and extracted_value != '':
      extracted_numeric = int(
          extracted_value.replace(".", "").replace(",", "."))
    return golden_numeric, extracted_numeric, None
  except:
    return None, None, 'Error parsing to int from european format'


# float parsers
def parse_european_format_for_floats(
    golden_value: Text, extracted_value: Text) -> Tuple[float, float, Text]:
  try:
    golden_numeric: Any = None
    extracted_numeric: Any = None
    if golden_value:
      golden_numeric = float(golden_value.replace(".", "").replace(",", "."))
    if extracted_value:
      extracted_numeric = float(
          extracted_value.replace(".", "").replace(",", "."))
    return golden_numeric, extracted_numeric, None
  except:
    return None, None, 'Error parsing to float from european format'


# default
def default_parser(golden_value: Text, extracted_value: Text,
                   schema_type: Text) -> Tuple[Any, Any, Text]:
  try:
    golden_raw_value: Any = None
    extracted_raw_value: Any = None
    if schema_type in [FLOAT, INT]:
      number_parser = int if schema_type == INT else float
      if golden_value:
        golden_raw_value = number_parser(golden_value.replace(",", ""))
      if extracted_value:
        extracted_raw_value = number_parser(extracted_value.replace(",", ""))
    else:
      golden_raw_value = golden_value
      extracted_raw_value = extracted_value
    return golden_raw_value, extracted_raw_value, None
  except:
    return None, None, f"Error parsing to schema type {schema_type}"


# Each comparator entry will contain:
#   fn: The function which will perform comparison
#   args: A dictionary mapping function argument names to their types
#   description: A description of how the comparator determines a match

ComparatorKwargDescDict = TypedDict('ComparatorKwargDescDict', {
    'label': Text,
    'value': Text
},
                                    total=False)

ComparatorDict = TypedDict('ComparatorDict', {
    'fn': Callable,
    'label': Text,
    'kwargs': Dict[Text, Text],
    'kwarg_desc': Dict[Text, List[ComparatorKwargDescDict]],
    'description': Text,
},
                           total=False)
ComparatorRegistry = Dict[Text, Dict[Text, ComparatorDict]]

comparators_by_type: ComparatorRegistry = {
    TEXT: {
        'ignore_chars':
            ComparatorDict(
                fn=ignore_chars,
                kwargs={
                    'whitespace': 'bool',
                    'special': 'bool'
                },
                label="Ignore the following characters",
                description=
                'Compares golden and extracted text with whitespace and/or special (#$%&\'()*+,-./:;<=>?@[\]^_`{|}~) characters removed.'
            ),
        'case_insensitive':
        ComparatorDict(
            fn=case_insensitive,
            label="Ignore Case",
            description=
            'Performs case-insensitive comparison between golden and extracted text'
        ),
        'date_string':
            ComparatorDict(
                fn=date_string,
                label="Compare as Date",
                description=
                'Compares golden and extracted text converted to date format.'),
        'levenshtein_distance':
        ComparatorDict(
            fn=levenshtein,
            kwargs={'max_distance': 'int'},
            label="Allow levenshtein distance",
            description=
            'Compares golden and extracted text with an allowed levenshetin difference.'
        ),
    },
    INT: {
        'allow_max_diff_for_ints':
            ComparatorDict(
                fn=allow_max_diff_for_ints,
                kwargs={'max_difference': 'int'},
                label="Allow Error Tolerance",
                description=
                'Compares golden and extracted integers with an max allowed difference in whole numbers'
            )
    },
    FLOAT: {
        'allow_max_diff_for_floats':
            ComparatorDict(
                fn=allow_max_diff_for_floats,
                kwargs={'max_difference': 'float'},
                label="Allow Error Tolerance",
                description=
                'Compares golden and extracted floats with an allowed difference.'
            ),
        'round_float':
            ComparatorDict(
                fn=round_float,
                kwargs={
                    'round_type': 'enum',
                },
                kwarg_desc={
                    'round_type': [{
                        'label': 'Round',
                        'value': 'nearest_int'
                    }, {
                        'label': 'Round down',
                        'value': 'floor'
                    }, {
                        'label': 'Round up',
                        'value': 'ceil'
                    }]
                },
                label="Round Number",
                description=
                'Compares golden and extracted floats rounded to nearest integer in specified direction.'
            )
    }
}

parsers_by_type: ComparatorRegistry = {
    INT: {
        'parse_european_format_for_ints':
        ComparatorDict(
            fn=parse_european_format_for_ints,
            label="Compare in European Number Format",
            description=
            'Compares golden and extracted ints with the European number format.'
        ),
    },
    FLOAT: {
        'parse_european_format_for_floats':
        ComparatorDict(
            fn=parse_european_format_for_floats,
            label="Compare in European Number Format",
            description=
            'Compares golden and extracted floats with the European number format.'
        ),
    }
}