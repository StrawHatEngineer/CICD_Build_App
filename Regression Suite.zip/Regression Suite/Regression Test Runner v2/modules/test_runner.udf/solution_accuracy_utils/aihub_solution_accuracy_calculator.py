from typing import Dict, Text, Tuple, List
import os
import logging

from .consts import TABLE, GOLDEN_DATA_EXCEL_FILE_NAME, \
    GOLDEN_TABLES_EXCEL_FILE_NAME, GOLDEN_PAGE_SPLITS_EXCEL_FILE_NAME, \
    SCHEMA_FILE_NAME, EXTRACTED_TABLE, EXTRACTED_TABLES_LIST, NESTED_FIELDS
from .solution_accuracy_calculator import SolutionAccuracyCalculator
from ..services.file_service import FileService
from .solution_accuracy_utils import MergedRawDataDict, GoldenColToExtractedFieldDict, ComparisonLogicDict, GoldenClassDict, GoldenValueDict, IBResultsClassDict, ValueComparisonDict, MergedRawDataRecordDict, construct_field_raw_data, check_field_flagged_for_review, generate_records_aggregated_by_field, MergedRawDataClassDict, PageComparisonDict, merge_golden_and_extracted_page_splits

class AIHubSolutionAccuracyCalculator(SolutionAccuracyCalculator):

  def __init__(self,
               ibresults_dict: Text,
               access_token: Text,
               out_path: Text,
               app_name: Text,
               clients,
               summary_dict: dict,
               accuracy_source_dir: Text,   
               api_base_url: str):
    
    self._access_token = access_token
    self._api_base_url = api_base_url
    self._out_path = out_path
    self._app_name = app_name
    self._clients = clients
    self._summary_dict = summary_dict
    self.accuracy_source_dir = accuracy_source_dir
    self.file_service = FileService(self._access_token, self._api_base_url)
    self.golden_id = os.path.basename(accuracy_source_dir)

    # This variable is used to determine whether to include page ranges check in determinng if a record was classified correctly
    # Default is False for enterprise solution accuracy calculator
    self.include_page_ranges_check = False

    # This variable is used to determine when denominator is 0 whether we want to compute the metric as 0 or None
    self.useNoneForNotApplicableMetrics = False

    # This variable is used to determine if accuracy metrics for nested fields should be calculated through an all or nothing comparison or element/cell based
    self.matchCompleteNestedFields = False

    # This variable is used to determine if global/field level config rules should apply to the elements of nested fields
    self.persistConfigsToNestedElements = False

    # This variable is used to determine whether the flow name should be used as the class label for documents without class as opposed to some other class name constant
    self.use_flow_name_for_class_label = True

    if not self.file_service.check_path_exists(accuracy_source_dir):
        raise Exception('Golden dataset {} dir not found at path {}'.format(self.golden_id, accuracy_source_dir))

    self.golden_data_excel_path = os.path.join(accuracy_source_dir,
                                               GOLDEN_DATA_EXCEL_FILE_NAME)
    self.golden_tables_excel_path = os.path.join(
        accuracy_source_dir, GOLDEN_TABLES_EXCEL_FILE_NAME)
    self.golden_page_splits_excel_path = os.path.join(
        accuracy_source_dir, GOLDEN_PAGE_SPLITS_EXCEL_FILE_NAME)

    # Check that ibflowresults path is valid
    if not ibresults_dict or len(ibresults_dict) == 0:
            raise Exception('IBResults not found')
    self.ibresults_dict = ibresults_dict
    self.record_metadata: Dict = {}

    # Check that schema json exists in correct spot
    schema_path = os.path.join(accuracy_source_dir, SCHEMA_FILE_NAME)
    if not self.file_service.check_path_exists(schema_path, path_type="file"):
        raise Exception(
            'No schema file found in designated spot: {}'.format(schema_path))
    self.schema_path = schema_path

    self.record_metadata: Dict = {}
    self.golden_page_splits: Dict = {}
    self.golden_page_ranges: Dict = {}
    self.ibresults_page_splits: Dict = {}

  def get_metrics_dir_path(self, job_id: Text) -> Tuple[Text, Text]:
    accuracy_dir_path = os.path.join(self.accuracy_source_dir, "accuracy")
    return accuracy_dir_path, None

  def _get_golden_id_to_class_map(self,
                                  golden_records: GoldenClassDict) -> Dict:
    id_to_class = {}
    for class_label, class_dict in golden_records.items():
      for id in class_dict:
        id_to_class[id] = class_label

    return id_to_class

  def _get_is_match_map(
      self,
      raw_data: MergedRawDataDict) -> Dict[Text, Dict[Text, Dict[Text, bool]]]:
    """
    This function returns a dict that maps as follows:
    return_dict[ground_truth_classification][record_id][field_name] = is_match value
    """
    return_dict: Dict[Text, Dict[Text, Dict[Text, bool]]] = {}
    for class_name, class_dict in raw_data["classes"].items():
      return_dict[class_name] = {}
      for record_dict in class_dict["records"]:
        return_dict[class_name][record_dict["name"]] = {
            field["name"]: field["is_match"]
            for field in record_dict["fields"] if not field.get("skipped")
        }
    logging.debug(f"is_match_map: {return_dict}")
    return return_dict

  def merge_golden_and_ibresults(
      self, golden_to_extracted_field_map: GoldenColToExtractedFieldDict,
      comparison_logic: ComparisonLogicDict, golden_records: GoldenClassDict,
      ibresults_records: IBResultsClassDict) -> Tuple[MergedRawDataDict, Text]:
    """
    Merges ibflowresults data into golden data so that we can get a side-by-side comparison
    of extracted value vs golden value for every field filled out in the golden dataset.
    """
    merged_raw_data = MergedRawDataDict(classes={})
    # Scan through golden records dictionary
    # Insert the extracted field value for each golden record / column
    for ibresults_class_label, ibresults_class_dict in ibresults_records.items():
      merged_raw_data_for_class = MergedRawDataClassDict(records=[], fields=[])
      merged_records_for_class_list = []
      for ibresults_record_id, ibresults_record_dict in ibresults_class_dict.items():
        golden_record_page_ranges_dict = self.golden_page_ranges.get(
            ibresults_record_id, {})

        was_classified_correctly = ibresults_record_id in golden_records.get(
            ibresults_class_label, {})
        was_record_flagged_for_review_for_classification_checkpoint = False
        was_page_ranges_equal = False
        if was_classified_correctly:
          was_page_ranges_equal = golden_record_page_ranges_dict.get(
              'page_start', -1) == ibresults_record_dict.get(
                  'page_start', -1) and golden_record_page_ranges_dict.get(
                      'page_end', -1) == ibresults_record_dict.get(
                          'page_end', -1)
          was_record_flagged_for_review_for_classification_checkpoint = ibresults_record_dict.get(
              'was_flagged_for_review', False)
        was_classified_correctly_and_page_ranges_equal = was_classified_correctly and was_page_ranges_equal
        was_record_flagged_for_review = False

        # Merge split classification information
        pages: List[
            PageComparisonDict] = merge_golden_and_extracted_page_splits(
                ibresults_record_id, self.golden_page_splits,
                self.ibresults_page_splits)

        merged_fields_for_record_list: List[ValueComparisonDict] = []
        logging.info(f"fields: {ibresults_record_dict}")
        for ibresults_field_name, ibresults_field_dict in ibresults_record_dict.items():
          # Get equivalent extracted field name
          logging.info("i am here")
          logging.info(f"field name: {ibresults_field_name}")
          extracted_field = golden_to_extracted_field_map.get(ibresults_class_label, {}).get(ibresults_field_name)
          if extracted_field is None:
            continue
          field_schema = comparison_logic.get('classes', {}).get(
              ibresults_class_label, {}).get('fields', {}).get(
                  extracted_field, {})
          schema_type = field_schema.get('type')
          schema_content_type = field_schema.get('contentType')
          skipped = field_schema.get('skipped', False)

          if schema_type not in NESTED_FIELDS and schema_content_type:
            logging.info(
                "Error: content type specified for a field that is not nested")

          extracted_value = ibresults_field_dict.get('extracted_value')
          checkpoint_results = ibresults_field_dict.get('checkpoint_results', {})
          golden_record = golden_records.get(ibresults_class_label, {}).get(ibresults_record_id, {})
          golden_value = golden_record.get(ibresults_field_name, {}).get('golden_value')
          field_dict = construct_field_raw_data(
              extracted_field, checkpoint_results, schema_type, golden_value,
              extracted_value, schema_content_type, skipped)
          was_record_flagged_for_review = was_record_flagged_for_review or check_field_flagged_for_review(field_dict)
          merged_fields_for_record_list.append(field_dict)
          logging.info(f"record_list :{merged_fields_for_record_list}")
        merged_records_for_class_list.append(
            MergedRawDataRecordDict(
                name=ibresults_record_id,
                fields=merged_fields_for_record_list,
                was_classified_correctly=
                was_classified_correctly_and_page_ranges_equal if
                self.include_page_ranges_check else was_classified_correctly,
                was_flagged_for_review=was_record_flagged_for_review,
                was_flagged_for_review_for_classification_checkpoint=
                was_record_flagged_for_review_for_classification_checkpoint,
                pages=pages))
      merged_raw_data_for_class['records'] = merged_records_for_class_list
      merged_raw_data['classes'][ibresults_class_label] = merged_raw_data_for_class
      logging.info(merged_records_for_class_list)

    # Add records aggregated by fields dictionary
    generate_records_aggregated_by_field(merged_raw_data)
    logging.info(f"VINAY DEBUG: {merged_raw_data}")
    return merged_raw_data, None