from collections import defaultdict
from io import BytesIO
from typing import Any, Dict, List, Text, Tuple
import json
import logging
import os
import pandas as pd
import urllib.parse

from .consts import TABLE, GOLDEN_DATA_EXCEL_FILE_NAME, \
    GOLDEN_TABLES_EXCEL_FILE_NAME, GOLDEN_PAGE_SPLITS_EXCEL_FILE_NAME, \
    SCHEMA_FILE_NAME, EXTRACTED_TABLE, EXTRACTED_TABLES_LIST, NESTED_FIELDS
from .solution_accuracy_utils import ComparisonLogicFieldDict, ComparisonLogicClassDict, ComparisonLogicDict, \
    validate_golden_schema, GoldenColToExtractedFieldDict, GoldenValueDict, GoldenClassDict, \
    IBResultsClassDict, get_checkpoint_results, IBResultsValueDict, MergedRawDataDict, MergedRawDataClassDict, \
    ValueComparisonDict, MergedRawDataRecordDict, construct_field_raw_data, generate_records_aggregated_by_field, \
    check_field_flagged_for_review, JobLevelAccuracyMetrics, ClassLevelAccuracyMetrics, \
    compute_record_and_field_level_metrics, generate_fields_aggregated_by_record
from ..services.file_service import FileService
from ..utils.path import ibpath


class SolutionAccuracyCalculator():

    def __init__(self, golden_path: Text, ibresults_dict: Text,
                 access_token: Text, out_path: Text, app_name: Text, clients,
                 summary_dict: dict, api_base_url: str):

        self._access_token = access_token
        self._api_base_url = api_base_url
        self._out_path = out_path
        self._app_name = app_name
        self._clients = clients
        self._summary_dict = summary_dict
        self.file_service = FileService(self._access_token, self._api_base_url)
        self.golden_id = os.path.basename(golden_path)
        if not self.file_service.check_path_exists(golden_path):
            raise Exception('Golden dataset {} dir not found at path {}'.format(
                self.golden_id, golden_path))

        self.golden_data_excel_path = os.path.join(golden_path,
                                                   GOLDEN_DATA_EXCEL_FILE_NAME)
        self.golden_tables_excel_path = os.path.join(
            golden_path, GOLDEN_TABLES_EXCEL_FILE_NAME)
        self.golden_page_splits_excel_path = os.path.join(
            golden_path, GOLDEN_PAGE_SPLITS_EXCEL_FILE_NAME)

        # Check that schema json exists in correct spot
        schema_path = os.path.join(golden_path, SCHEMA_FILE_NAME)
        if not self.file_service.check_path_exists(schema_path,
                                                   path_type="file"):
            raise Exception(
                'No schema file found in designated spot: {}'.format(
                    schema_path))
        self.schema_path = schema_path

        if not ibresults_dict or len(ibresults_dict) == 0:
            raise Exception('IBResults not found')
        self.ibresults_dict = ibresults_dict

        self.record_metadata: Dict = {}

    def compute_and_record_solution_accuracy(self) -> Tuple[Text, Text]:
        golden_to_extracted_field_map, comparison_logic, err = self.parse_schema_json(
        )
        if err:
            return None, f'While parsing schema.json: {err}'

        golden_records, err = self.get_golden_records(
            golden_to_extracted_field_map, comparison_logic)
        if err:
            return None, f'While getting golden records: {err}'

        ibresults_records, err = self.get_ibresults_records()
        if err:
            return None, f'While getting ibresults records: {err}'

        raw_data_aggregated_by_record_and_field, err = self.merge_golden_and_ibresults(
            golden_to_extracted_field_map, comparison_logic, golden_records,
            ibresults_records)
        if err:
            return None, f'While merging golden and ibresults records: {err}'

        accuracy_metrics = self.compute_accuracy_metrics(
            comparison_logic, raw_data_aggregated_by_record_and_field,
            comparison_logic.get('exemptMisclassifiedRecords', False))

        raw_data_path = f'{self._out_path}raw_data_aggregated_by_record_and_field.json'
        with self._clients.ibfile.open(raw_data_path, 'w') as f:
            f.write(
                json.dumps(raw_data_aggregated_by_record_and_field,
                           default=lambda o: getattr(o, '__dict__', str(o))))
        self._summary_dict[
            'Extracted_And_Golden_Data_Aggregated_URL'] = urllib.parse.quote(
                self._api_base_url + '/' + raw_data_path, safe='/:?=&')

        accuracy_metrics = self.compute_accuracy_metrics(
            comparison_logic, raw_data_aggregated_by_record_and_field,
            comparison_logic.get('exemptMisclassifiedRecords', False))

        metrics_path = f'{self._out_path}{self._app_name}_metrics.json'
        with self._clients.ibfile.open(metrics_path, 'w') as f:
            f.write(
                json.dumps(accuracy_metrics,
                           default=lambda o: getattr(o, '__dict__', str(o))))
        self._summary_dict['Current_Run_Metrics_URL'] = urllib.parse.quote(
            self._api_base_url + '/' + metrics_path, safe='/:?=&')
        return metrics_path, None

    def parse_schema_json(
        self
    ) -> Tuple[GoldenColToExtractedFieldDict, ComparisonLogicDict, Text]:
        """
            This method will parse the schema json and produce 2 separate dicts:
            1. a dict mapping a golden column name to its equivalent extracted field name
            2. a dict mapping each extracted field to its type and custom comparison logic
            """
        # Read in schema json file
        schema_contents, err = self.file_service.read_file(
            path=self.schema_path, path_type="file")
        if err:
            return None, None, f'While reading schema.json at {self.schema_path}: {err}'

        schema_json: Dict = {}
        try:
            schema_json = json.loads(schema_contents)
        except json.JSONDecodeError as e:
            return None, None, f'Schema file at {self.schema_path} was not JSON decodable: {str(e)}'
        err = validate_golden_schema(schema_json)
        if err:
            return None, None, f'Schema was not in expected shape: {err}'

        # Generate 2 maps:
        # golden_to_extracted_field will map a golden column to its equivalent extracted field
        # comparison logic will map an extracted field to its comparison logic
        golden_to_extracted_field_map = {}
        solution_level_comparison_strategy = schema_json.get(
            'comparisonStrategy', {})
        exempt_misclassified_records = schema_json.get(
            'exemptMisclassifiedRecords', False)
        comparison_logic = ComparisonLogicDict(
            comparisonStrategy=solution_level_comparison_strategy,
            classes={},
            exemptMisclassifiedRecords=exempt_misclassified_records)
        for schema_class_dict in schema_json['classes']:
            class_name = schema_class_dict['name']
            field_mappings = {}
            # Inherit keys from solution level comparisonStrategy
            class_level_comparison_strategy = {
                **solution_level_comparison_strategy,
                **schema_class_dict.get('comparisonStrategy', {})
            }
            class_level_comparison_logic = ComparisonLogicClassDict(
                comparisonStrategy=class_level_comparison_strategy, fields={})
            for schema_field_dict in schema_class_dict.get('fields'):
                golden_col_name = schema_field_dict['name']
                extracted_field_name = schema_field_dict['mappedTo']
                field_mappings[golden_col_name] = extracted_field_name

                # Inherit keys from class level comparisonStrategy
                field_level_comparison_strategy = {
                    **class_level_comparison_strategy,
                    **schema_field_dict.get('comparisonStrategy', {})
                }
                content_type = schema_field_dict.get('contentType')
                if schema_field_dict['type'] in [TABLE, EXTRACTED_TABLE]:
                    content_type = {}
                    field_level_comparison_strategy['headers'] = {}
                    for header in schema_field_dict.get('mappings',
                                                        {}).get('headers', []):
                        content_type[header['name']] = header['type']
                        field_level_comparison_strategy['headers'][
                            header['name']] = header.get('comparisonStrategy')

                if schema_field_dict['type'] == EXTRACTED_TABLES_LIST:
                    content_type = {'tables': []}
                    field_level_comparison_strategy['tables'] = []
                    for table in schema_field_dict.get('mappings',
                                                       {}).get('tables', []):
                        table_level_comparison_strategy: Dict[Text, Any] = {
                            'headers': {}
                        }
                        table_level_content_type = {}
                        for header in table.get('headers', []):
                            table_level_content_type[
                                header['name']] = header['type']
                            table_level_comparison_strategy['headers'][header[
                                'name']] = header.get('comparisonStrategy')
                        field_level_comparison_strategy['tables'].append(
                            table_level_comparison_strategy)
                        content_type['tables'].append(table_level_content_type)

                field_level_comparison_logic = ComparisonLogicFieldDict(
                    comparisonStrategy=field_level_comparison_strategy,
                    type=schema_field_dict['type'],
                    contentType=content_type)
                class_level_comparison_logic['fields'][
                    extracted_field_name] = field_level_comparison_logic
            golden_to_extracted_field_map[class_name] = field_mappings
            comparison_logic['classes'][
                class_name] = class_level_comparison_logic

        return golden_to_extracted_field_map, comparison_logic, None

    def get_golden_records(
            self, golden_to_extracted_field_map: GoldenColToExtractedFieldDict,
            comparison_logic: ComparisonLogicDict
    ) -> Tuple[GoldenClassDict, Text]:
        """
            Parse the golden excel data and golden excel table files to get a dictionary mapping
            each class to its records, each record to its fields, and each field to its golden values.
            """
        # Read in golden data excel file and open workbook
        golden_contents, err = self.file_service.read_file(
            self.golden_data_excel_path, path_type="file")
        if err:
            return None, f'Error while reading golden data at {self.golden_data_excel_path}: {err}'
        try:
            golden_xls = pd.ExcelFile(  # type: ignore
                BytesIO(golden_contents), engine='openpyxl')
            golden_dfs = pd.read_excel(golden_xls,
                                       sheet_name=None,
                                       dtype=str,
                                       engine='openpyxl',
                                       keep_default_na=False)
            # Replace NaN values with empty strings in each DataFrame
            for sheet_name, df in golden_dfs.items():
                golden_dfs[sheet_name] = df.fillna('')
        except Exception as e:
            # print(e)
            return None, f'Error reading excel: {str(e)}'

        # Read in golden excel file and open workbook
        golden_table_dfs = None
        if self.file_service.check_path_exists(self.golden_tables_excel_path,
                                               path_type="file"):
            golden_table_contents, err = self.file_service.read_file(
                self.golden_tables_excel_path, path_type="file")
            if err:
                return None, f'Error while reading golden table data at {self.golden_tables_excel_path}: {err}'
            try:
                golden_table_xls = pd.ExcelFile(  # type: ignore
                    BytesIO(golden_table_contents),
                    engine='openpyxl')
                golden_table_dfs = pd.read_excel(golden_table_xls,
                                                 sheet_name=None,
                                                 dtype=str,
                                                 engine='openpyxl',
                                                 keep_default_na=False)
                # Replace NaN values with empty strings in each DataFrame
                for sheet_name, df in golden_table_dfs.items():
                    golden_table_dfs[sheet_name] = df.fillna('')
            except Exception as e:
                return None, f'Error reading Excel: {str(e)}'

        class_dict: Dict = defaultdict(dict)
        # print(golden_dfs)
        for class_label, class_df in golden_dfs.items():
            rows = list(class_df.iterrows())
            if len(rows) < 1:
                # Any sheet with data will have at least 1 data row
                continue

            # If any column doesnt exist in the passed in golden_to_extracted_field_map, a field may be missing in
            # schema.json
            if class_label not in golden_to_extracted_field_map:
                return None, f'Class label {class_label} appeared in golden but did not appear in schema.json'
            for i, column_name in enumerate(class_df.columns):
                # Exclude record_id (the first column) in this check
                if i > 0 and column_name not in golden_to_extracted_field_map[
                        class_label]:
                    return None, f'Field {column_name} appeared in golden for class {class_label} but did not appear in schema.json'

            # Every row after the first row represents a unique record
            for _, row in rows:
                record_dict = {}
                # Record ID will always be in the first column
                record_id = row['record_id']
                for col_name, golden_value in row.iloc[1:].items():
                    field_dict = GoldenValueDict(golden_col=col_name,
                                                 golden_value=golden_value)
                    extracted_field = golden_to_extracted_field_map.get(
                        class_label, {}).get(col_name)
                    schema_type = comparison_logic.get('classes', {}).get(
                        class_label, {}).get('fields',
                                             {}).get(extracted_field,
                                                     {}).get('type')
                    # If we are dealing with a table, we must get the table contents from its sheet in table.xlsx
                    if schema_type and (schema_type == TABLE or
                                        schema_type == EXTRACTED_TABLE):
                        sheet_name = golden_value
                        if not golden_table_dfs:
                            return None, 'Table type selected for golden column {} but no tables excel found.'.format(
                                col_name)
                        table_sheet = golden_table_dfs.get(sheet_name)
                        if table_sheet is None:
                            return None, 'Could not find sheet in golden tables excel for table field {}.'.format(
                                sheet_name)
                        golden_table = json.dumps(
                            [table_sheet.columns.tolist()] +
                            table_sheet.values.tolist())
                        field_dict['golden_value'] = golden_table

                    # If we are dealing with a list of tables, we must get the table contents from their sheets in
                    # table.xlsx
                    if schema_type and schema_type == EXTRACTED_TABLES_LIST:
                        sheet_names_str = golden_value
                        if not golden_table_dfs:
                            return None, 'Tables list type selected for golden column {} but no tables excel found.'.format(
                                col_name)
                        sheet_names_list: List[Text] = []
                        try:
                            sheet_names_list = json.loads(sheet_names_str)
                        except json.JSONDecodeError:
                            return None, 'could not decode table IDs. Got values list {}'.format(
                                sheet_names_str)

                        golden_tables_list = []
                        for table_id in sheet_names_list:
                            table_sheet = golden_table_dfs.get(table_id)
                            if table_sheet is None:
                                return None, 'Could not find sheet in golden tables excel for table field {}.'.format(
                                    table_id)
                            table_value = [table_sheet.columns.tolist()
                                          ] + table_sheet.values.tolist()
                            golden_tables_list.append(table_value)
                        field_dict['golden_value'] = json.dumps(
                            golden_tables_list)
                    record_dict[col_name] = field_dict
                class_dict[class_label][record_id] = record_dict
        # print(class_dict)
        return class_dict, None

    def get_ibresults_records(self) -> Tuple[IBResultsClassDict, Text]:
        """
            Parse the ibflowresults file to get a dictionary mapping
            each class to its records, each record to its extracted fields,
            and each extracted field to its extracted values.
            """
        class_dict: Dict = defaultdict(dict)
        # print(len(self.ibresults_dict.get('records', [])))
        for record in self.ibresults_dict.get('records', []):
            if 'output_file_path' not in record:
                logging.info(
                    'Skipping record as it does not have a output_file_path field'
                )
                continue
            file_name = ibpath.strip_ext(
                os.path.basename(record['output_file_path']))
            record_index = record.get('record_index', 0)
            record_id = '{}_{}'.format(file_name, record_index)
            class_label = record.get('classification_label', '')
            # Default non-classified documents to have a class equivalent to flow name
            implied_class_label = class_label
            # If record had a checkpoint result, check to see if any fields were flagged for review
            checkpoint_results = get_checkpoint_results(record)
            # checkpoint_results = get_checkpoint_results(record, self.__clients)

            record_dict = {}
            for result_dict in record.get('results', []):
                field_name = result_dict.get('key')
                extracted_value = result_dict.get('value')
                # fields starting with '__' are considered hidden and thus we do not compute accuracy metrics on them
                if not field_name.startswith('__'):
                    record_dict[field_name] = IBResultsValueDict(
                        name=field_name,
                        extracted_value=extracted_value,
                        checkpoint_results=checkpoint_results.get(
                            field_name, {}))

            class_dict[implied_class_label][record_id] = record_dict
        return class_dict, None

    def merge_golden_and_ibresults(
        self, golden_to_extracted_field_map: GoldenColToExtractedFieldDict,
        comparison_logic: ComparisonLogicDict, golden_records: GoldenClassDict,
        ibresults_records: IBResultsClassDict
    ) -> Tuple[MergedRawDataDict, Text]:
        """
            Merges ibflowresults data into golden data so that we can get a side-by-side comparison
            of extracted value vs golden value for every field filled out in the golden dataset.
            """
        merged_raw_data = MergedRawDataDict(classes={})
        # Scan through golden records dictionary
        # Insert the extracted field value for each golden record / column
        for golden_class_label, golden_class_dict in golden_records.items():
            merged_raw_data_for_class = MergedRawDataClassDict(records=[],
                                                               fields=[])
            merged_records_for_class_list = []
            for golden_record_id, golden_record_dict in golden_class_dict.items(
            ):
                # If this record ID has the same class in both ibresults and golden dataset, it has been classified correctly
                was_classified_correctly = golden_record_id in ibresults_records.get(
                    golden_class_label, {})
                was_record_flagged_for_review = False
                # Merge split classification information
                # pages: List[
                #     PageComparisonDict] = merge_golden_and_extracted_page_splits(
                #     golden_record_id, self.golden_page_splits,
                #     self.ibresults_page_splits)

                merged_fields_for_record_list: List[ValueComparisonDict] = []
                for golden_col, golden_field_dict in golden_record_dict.items():
                    # Get equivalent extracted field name
                    extracted_field = golden_to_extracted_field_map.get(
                        golden_class_label, {}).get(golden_col)
                    ibresults_values = ibresults_records.get(
                        golden_class_label,
                        {}).get(golden_record_id, {}).get(extracted_field, {})
                    field_schema = comparison_logic.get('classes', {}).get(
                        golden_class_label,
                        {}).get('fields', {}).get(extracted_field, {})
                    schema_type = field_schema.get('type')
                    schema_content_type = field_schema.get('contentType')

                    if schema_type not in NESTED_FIELDS and schema_content_type:
                        logging.info(
                            "Error: content type specified for a field that is not nested"
                        )

                    extracted_value = ibresults_values.get('extracted_value')
                    checkpoint_results = ibresults_values.get(
                        'checkpoint_results', {})
                    golden_value = golden_field_dict.get('golden_value')
                    field_dict = construct_field_raw_data(
                        extracted_field, checkpoint_results, schema_type,
                        golden_value, extracted_value, schema_content_type)
                    was_record_flagged_for_review = was_record_flagged_for_review or check_field_flagged_for_review(
                        field_dict)
                    merged_fields_for_record_list.append(field_dict)
                merged_records_for_class_list.append(
                    MergedRawDataRecordDict(
                        name=golden_record_id,
                        fields=merged_fields_for_record_list,
                        was_classified_correctly=was_classified_correctly,
                        was_flagged_for_review=was_record_flagged_for_review,
                        pages=[]))
            merged_raw_data_for_class['records'] = merged_records_for_class_list
            merged_raw_data['classes'][
                golden_class_label] = merged_raw_data_for_class

        # Add records aggregated by fields dictionary
        generate_records_aggregated_by_field(merged_raw_data)
        logging.info(f"VINAY DEBUG: {merged_raw_data}")
        return merged_raw_data, None

    @classmethod
    def compute_accuracy_metrics(
            self,
            comparison_logic: ComparisonLogicDict,
            raw_data_aggregated_by_record_and_field: MergedRawDataDict,
            exempt_misclassified_records: bool = False
    ) -> JobLevelAccuracyMetrics:
        """
            Computes accuracy metrics at job-level, class-level, field-level, and record-level according to the generated raw data.
            """
        job_level_metrics = JobLevelAccuracyMetrics()
        # Counters to keep track of job-level accuracy
        for class_label, class_dict in raw_data_aggregated_by_record_and_field[
                'classes'].items():
            # Counters to keep track of class-level accuracy
            class_level_metrics = ClassLevelAccuracyMetrics(class_label)
            record_level_metrics, field_level_metrics = compute_record_and_field_level_metrics(
                comparison_logic['classes'][class_label], class_dict,
                exempt_misclassified_records)
            for record_metrics in record_level_metrics.values():
                # Increment counters for class-level accuracy
                class_level_metrics.total += record_metrics.total
                class_level_metrics.total_automated += record_metrics.total_automated
                class_level_metrics.total_automated_correct += record_metrics.total_automated_correct
                class_level_metrics.total_human_review += record_metrics.total_human_review
                class_level_metrics.total_human_review_correct += record_metrics.total_human_review_correct
                class_level_metrics.total_splits += record_metrics.total_splits
                class_level_metrics.total_splits_correct += record_metrics.total_splits_correct

            records = class_dict['records']
            for record in records:
                class_level_metrics.total_records += 1
                if record['was_classified_correctly']:
                    class_level_metrics.total_records_classified_correctly += 1
                if record['was_flagged_for_review']:
                    class_level_metrics.total_records_flagged_for_review += 1

            # Class-level metrics completed
            class_level_metrics.compute_percent_fields()
            class_level_metrics.field_metrics = field_level_metrics
            class_level_metrics.record_metrics = record_level_metrics

            # Insert completed class metrics into job-level dictionary
            job_level_metrics.classes.append(class_level_metrics)

            # Increment counters for job-level accuracy
            job_level_metrics.total += class_level_metrics.total
            job_level_metrics.total_records += class_level_metrics.total_records
            job_level_metrics.total_records_flagged_for_review += class_level_metrics.total_records_flagged_for_review
            job_level_metrics.total_automated += class_level_metrics.total_automated
            job_level_metrics.total_automated_correct += class_level_metrics.total_automated_correct
            job_level_metrics.total_human_review += class_level_metrics.total_human_review
            job_level_metrics.total_human_review_correct += class_level_metrics.total_human_review_correct
            job_level_metrics.total_splits += class_level_metrics.total_splits
            job_level_metrics.total_splits_correct += class_level_metrics.total_splits_correct

        # Persist is-match flag onto fields aggregated by record
        generate_fields_aggregated_by_record(
            raw_data_aggregated_by_record_and_field)

        # Job-level metrics completed
        job_level_metrics.compute_percent_fields()

        return job_level_metrics
