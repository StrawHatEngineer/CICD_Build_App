from collections import defaultdict

from typing import Any, Dict, List, Text, Tuple, Union
import json
import logging
from mypy_extensions import TypedDict

import pandas as pd

from .comparator_registry import comparators_by_type
from .consts import DICT, EXTRACTED_TABLE, EXTRACTED_TABLES_LIST, FLOAT, INT, LIST, TABLE, TEXT, TEXT_LIST, OBJECT_LIST, NESTED_FIELDS, ACCURACY_DIR_NAME, GOLDEN_REGISTRY_FILE_NAME
from .table_comparator import TableComparator

GoldenColToExtractedFieldDict = Dict[Text, Dict[Text, Text]]

ComparisonLogicFieldDict = TypedDict('ComparisonLogicFieldDict', {
    'comparisonStrategy': Dict[Text, Any],
    'type': Text,
    'contentType': Any,
},
                                     total=False)

ComparisonLogicClassDict = TypedDict('ComparisonLogicClassDict', {
    'comparisonStrategy': Dict[Text, Any],
    'fields': Dict[Text, ComparisonLogicFieldDict]
},
                                     total=False)

ComparisonLogicDict = TypedDict('ComparisonLogicDict', {
    'comparisonStrategy': Dict[Text, Any],
    'classes': Dict[Text, ComparisonLogicClassDict],
    'exemptMisclassifiedRecords': bool
},
                                total=False)

IBResultsValueDict = TypedDict('IBResultsValueDict', {
    'name': Text,
    'extracted_value': Text,
    'checkpoint_results': Dict[Text, Any]
},
                               total=False)
IBResultsClassDict = Dict[Text, Dict[Text, Dict[Text, IBResultsValueDict]]]

GoldenValueDict = TypedDict('GoldenValueDict', {
    'golden_col': Text,
    'golden_value': Text
})

GoldenClassDict = Dict[Text, Dict[Text, Dict[Text, GoldenValueDict]]]


def validate_golden_schema(schema_json: Dict) -> Text:
    """ This helper method ensures that the passed in schema is of the expected shape
  """
    if 'classes' not in schema_json:
        return 'Missing key "classes"'
    for class_dict in schema_json['classes']:
        for class_key in ['name', 'fields']:
            if class_key not in class_dict:
                return f'Missing key in class: {class_key}'
        for field_dict in class_dict['fields']:
            for field_key in ['name', 'type', 'mappedTo']:
                if field_key not in field_dict:
                    return f"Missing key in field for class {class_dict['name']}: {field_key}"
    return None


def get_golden_page_splits(golden_df: pd.DataFrame) -> Tuple[Dict, Text]:
    ret_data: Dict[Text, Any] = {}
    if golden_df.columns[0] != 'record_id':
        return None, 'First cell of golden excel file must be \"record_id\"'

    for i in range(len(golden_df)):
        record_id = golden_df.iloc[i, 0]
        page_class_label = golden_df.iloc[i, 1]
        page_start = golden_df.iloc[i, 2]
        page_end = golden_df.iloc[i, 3]

        # Initialize record ID in golden page splits dictionary
        if not record_id:
            continue
        if record_id not in ret_data:
            ret_data[record_id] = {}

        try:
            page_start = int(page_start)
            page_end = int(page_end)
        except:
            # If page start or page end are not castable to int,
            # leave the record empty
            continue

        for i in range(page_start, page_end + 1):
            ret_data[record_id][i] = page_class_label

    return ret_data, None


IBResultsValueDict = TypedDict('IBResultsValueDict', {
    'name': Text,
    'extracted_value': Text,
    'checkpoint_results': Dict[Text, Any]
},
                               total=False)
IBResultsClassDict = Dict[Text, Dict[Text, Dict[Text, IBResultsValueDict]]]


def get_checkpoint_results(record: Dict) -> Dict:
    fields_flagged_for_review = {}
    checkpoint_results = record.get('checkpoint_results', {}).get('results', [])
    checkpoint_ibvalidation_results = record.get('checkpoint_results', {}).get(
        'validation_results', {})
    if len(checkpoint_ibvalidation_results) > 0:
        for field, result in checkpoint_ibvalidation_results.items():
            if result.get('valid') is False:
                if not result.get('failures', []):
                    result['valid'] = True
                fields_flagged_for_review[field] = result
    else:
        for checkpoint_result in checkpoint_results:
            if checkpoint_result.get('valid') is False:
                for field in checkpoint_result.get('fields', []):
                    fields_flagged_for_review[field] = {'valid': False}
    return fields_flagged_for_review


ValueComparisonDict = TypedDict('ValueComparisonDict', {
    'golden_value': Any,
    'extracted_value': Any,
    'values': Dict[Text, Any],
    'name': Text,
    'is_match': bool,
    'was_flagged_for_review': bool,
    'errs': List[Text]
},
                                total=False)

PageComparisonDict = TypedDict(
    'PageComparisonDict', {
        'page_number': int,
        'golden_class': Text,
        'extracted_class': Text,
        'is_match': bool
    })

ClassificationInfoDict = TypedDict('ClassificationInfoDict', {
    'class_label': Text,
    'page_start': int,
    'page_end': int
})

RecordComparisonDict = TypedDict(
    'RecordComparisonDict', {
        'golden_value': ClassificationInfoDict,
        'classified_value': ClassificationInfoDict,
        'is_match': bool,
        'was_flagged_for_review': bool,
        'validation_failure_messages': List[Text]
    })

MergedRawDataRecordDict = TypedDict(
    'MergedRawDataRecordDict', {
        'name': Text,
        'fields': List[ValueComparisonDict],
        'was_classified_correctly': bool,
        'was_flagged_for_review': bool,
        'pages': List[PageComparisonDict]
    })

MergedRawDataFieldDict = TypedDict('MergedRawDataFieldDict', {
    'name': Text,
    'records': List[ValueComparisonDict]
})

# Class-level raw data structure
MergedRawDataClassDict = TypedDict(
    'MergedRawDataClassDict', {
        'records': List[MergedRawDataRecordDict],
        'fields': List[MergedRawDataFieldDict]
    })
# Flow-level raw data structure
MergedRawDataDict = TypedDict('MergedRawDataDict',
                              {'classes': Dict[Text, MergedRawDataClassDict]})


def construct_leaf_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    # Cast golden and extracted to string if they are not None
    return ValueComparisonDict(
        golden_value=str(golden_value) if golden_value else golden_value,
        extracted_value=str(extracted_value)
        if extracted_value else extracted_value,
        was_flagged_for_review=checkpoint_results.get('valid', True) is False)


def construct_field_raw_data(extracted_field: Text,
                             checkpoint_results: Dict,
                             schema_type: Text,
                             golden_value: Text,
                             extracted_value: Text,
                             schema_content_type: Union[Text, Dict] = None,
                             skipped: bool = False) -> ValueComparisonDict:
    # Construct nested raw data structure for tables, lists, and dicts
    values_dict = None
    if schema_type and (schema_type in [TABLE, EXTRACTED_TABLE]):
        values_dict = construct_table_field_raw_data(
            golden_value,
            extracted_value,
            schema_content_type,
            checkpoint_results=checkpoint_results)
    elif schema_type and schema_type == DICT:
        values_dict = construct_dict_field_raw_data(
            golden_value,
            extracted_value,
            schema_content_type,
            checkpoint_results=checkpoint_results)
    elif schema_type and (schema_type in [LIST, TEXT_LIST]):
        values_dict = construct_list_field_raw_data(
            golden_value,
            extracted_value,
            schema_content_type,
            checkpoint_results=checkpoint_results)
    elif schema_type and schema_type == OBJECT_LIST:
        values_dict = construct_object_list_field_raw_data(
            golden_value,
            extracted_value,
            schema_content_type,
            checkpoint_results=checkpoint_results)
    elif schema_type and schema_type == EXTRACTED_TABLES_LIST:
        values_dict = construct_extracted_tables_list_field_raw_data(
            golden_value,
            extracted_value,
            schema_content_type,
            checkpoint_results=checkpoint_results)
    else:
        values_dict = construct_leaf_field_raw_data(
            golden_value,
            extracted_value,
            checkpoint_results=checkpoint_results)
    values_dict['name'] = extracted_field
    if skipped:
        values_dict['skipped'] = skipped
    return values_dict


def construct_table_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        headers_to_types: Union[Text, Dict] = None,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    golden_table, has_golden_type_err = json_loads(golden_value, default=[[]])
    extracted_table, has_extracted_type_err = json_loads(extracted_value,
                                                         default=[[]])
    values_dict = {}

    if not headers_to_types:
        headers_to_types = {}
    elif not isinstance(headers_to_types, dict):
        logging.info(
            "Error in constructing raw data: schema_content_type for a table field must be a dict. Proceeding to ignore this parameter..."
        )
        headers_to_types = {}

    # construct a type_per_index assuming the first row has headers
    type_per_index = []
    headers = golden_table[0]
    for header in headers:
        type_per_index.append(headers_to_types.get(header))

    # If table is invalid at top level, mark every cell as invalid
    top_level_table_valid = checkpoint_results.get('valid', True)

    #update the extracted table row/column postion to have best match with golden table
    comparator = TableComparator(match_config={})
    #update extracted data with new aligned data
    extracted_table = comparator.get_aligned_extracted_data_2d(
        golden_table,
        extracted_table,
        key_columns=[],
        ignore_extra_columns=True,
        ignore_extra_rows=True)
    logging.info("\n=== Alignment Results ===")
    for x, y in zip(golden_table, extracted_table):
        logging.info(x)
        logging.info(y)
        logging.info("========")

    # Leverage list raw data structure for each row of table
    for i, golden_table_content in enumerate(golden_table):
        row_checkpoint_results = [
            cell_checkpoint_result for cell_checkpoint_result in
            checkpoint_results.get('table_contents', [])
            if cell_checkpoint_result.get('table_index') == 0 and
            cell_checkpoint_result.get('row_start_index') == i
        ]
        list_contents = []
        for index_checkpoint_result in row_checkpoint_results:
            list_contents.append({
                'list_index': index_checkpoint_result.get('col_start_index'),
                'valid': index_checkpoint_result.get('valid')
            })
        list_checkpoint_results = {
            'list_contents': list_contents,
            'valid': top_level_table_valid
        }
        if i == 0:  # for the 1st row, let the type be text (use this function's default behavior)
            values_dict[str(i)] = construct_list_field_raw_data(
                json.dumps(golden_table_content),
                json.dumps(
                    extracted_table[i] if i < len(extracted_table) else []),
                checkpoint_results=list_checkpoint_results)
        else:
            values_dict[str(i)] = construct_list_field_raw_data(
                json.dumps(golden_table_content),
                json.dumps(
                    extracted_table[i] if isinstance(extracted_table, list) and
                    i < len(extracted_table) else []),
                None,
                type_per_index,
                checkpoint_results=list_checkpoint_results)

    comparison_dict = ValueComparisonDict(values=values_dict)
    if has_golden_type_err:
        comparison_dict.setdefault(
            'errs', []).append('Golden value could not be converted to table.')
    if has_extracted_type_err:
        comparison_dict.setdefault(
            'errs',
            []).append('Extracted value could not be converted to table.')
    return comparison_dict


def construct_extracted_tables_list_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        tables_to_types: Union[Text, Dict] = None,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    golden_tables_list, has_golden_type_err = json_loads(golden_value,
                                                         default=[[]])
    extracted_tables_list, has_extracted_type_err = json_loads(extracted_value,
                                                               default=[[]])
    values_dict = {}

    if not tables_to_types:
        tables_to_types = {}
    elif not isinstance(tables_to_types, dict):
        logging.info(
            "Error in constructing raw data: schema_content_type for an extracted_tables_list field must be a dict. Proceeding to ignore this parameter..."
        )
        tables_to_types = {}

    for i in range(len(golden_tables_list)):
        headers_to_types: Dict = {}
        if tables_to_types and 'tables' in tables_to_types and len(
                tables_to_types['tables']) > i:
            headers_to_types = tables_to_types['tables'][i]
        golden_table = golden_tables_list[i]
        extracted_table = extracted_tables_list[i] if i < len(
            extracted_tables_list) else []
        table_raw_data = construct_table_field_raw_data(
            json.dumps(golden_table), json.dumps(extracted_table),
            headers_to_types, checkpoint_results)
        values_dict[str(i)] = table_raw_data

    comparison_dict = ValueComparisonDict(values=values_dict)
    if has_golden_type_err:
        comparison_dict.setdefault(
            'errs',
            []).append('Golden value could not be converted to list of tables.')
    if has_extracted_type_err:
        comparison_dict.setdefault('errs', []).append(
            'Extracted value could not be converted to list of tables.')
    return comparison_dict


# Produces dict raw data structure for a golden/extracted dict pair
def construct_dict_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        content_type: Union[Text, Dict] = None,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    golden_dict, has_golden_type_err = json_loads(golden_value, default={})
    extracted_dict, has_extracted_type_err = json_loads(extracted_value,
                                                        default={})
    values_dict: Dict[Text, ValueComparisonDict] = {}

    if not isinstance(content_type, str) and content_type is not None:
        logging.info(
            "Error in constructing raw data: schema_content_type for a dict field must be a str. Proceeding to ignore this parameter..."
        )
        content_type = None

    comparison_dict = ValueComparisonDict(values=values_dict)
    for key, value in golden_dict.items():
        # The value that each key of a dict field is mapped to can be any type
        if isinstance(value, dict):
            values_dict[key] = construct_dict_field_raw_data(
                json.dumps(value),
                json.dumps(extracted_dict.get(key, {})),
                content_type,
                checkpoint_results=checkpoint_results)
        elif isinstance(value, list):
            values_dict[key] = construct_list_field_raw_data(
                json.dumps(value),
                json.dumps(extracted_dict.get(key, [])),
                None,
                checkpoint_results=checkpoint_results)
        else:
            if content_type and content_type not in ['INT', 'FLOAT', 'TEXT']:
                comparison_dict.setdefault(
                    'errs', []).append('Invalid contentType in golden schema.')
            elif content_type == 'INT':
                values_dict[key] = construct_int_field_raw_data(
                    str(value),
                    str(extracted_dict.get(key)),
                    checkpoint_results=checkpoint_results)
            elif content_type == 'FLOAT':
                values_dict[key] = construct_float_field_raw_data(
                    str(value),
                    str(extracted_dict.get(key)),
                    checkpoint_results=checkpoint_results)
            else:
                values_dict[key] = construct_text_field_raw_data(
                    value,
                    extracted_dict.get(key),
                    checkpoint_results=checkpoint_results)

    if has_golden_type_err:
        comparison_dict.setdefault(
            'errs', []).append('Golden value could not be converted to dict.')
    if has_extracted_type_err:
        comparison_dict.setdefault(
            'errs',
            []).append('Extracted value could not be converted to dict.')
    return comparison_dict


def json_loads(value: Text, default: Any = None) -> Tuple[Any, bool]:
    """
  This function attempts json.loads on the given value.

  Returns: a tuple where the first index is the converted value, or the default value if the conversion failed,
                     and the second index is a boolean denoting if the conversion had an error.
  """
    try:
        return json.loads(value), False
    except Exception:
        return default, True


def merge_golden_and_extracted_page_splits(
        golden_record_id: Text, golden_page_splits: Dict,
        ibresults_page_splits: Dict) -> List[PageComparisonDict]:
    pages: List[PageComparisonDict] = []
    file_name = golden_record_id.rsplit('_', 1)[0]
    # Scan through each page in the golden record
    for page_num in golden_page_splits.get(golden_record_id, {}):
        golden_page_class = golden_page_splits.get(golden_record_id,
                                                   {}).get(page_num, '')
        extracted_page_class = ibresults_page_splits.get(file_name,
                                                         {}).get(page_num, '')
        # Append the ground truth page with its expected and extracted class labels
        pages.append(
            PageComparisonDict(
                page_number=page_num,
                golden_class=golden_page_class,
                extracted_class=extracted_page_class,
                is_match=golden_page_class == extracted_page_class))
    return pages


# Produces list raw data structure for a golden/extracted list pair
def construct_list_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        content_type: Union[Text, Dict] = None,
        type_per_index: List = None,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    golden_list, has_golden_type_err = json_loads(golden_value, default=[])
    extracted_list, has_extracted_type_err = json_loads(extracted_value,
                                                        default=[])
    values_dict: Dict[Text, ValueComparisonDict] = {}
    comparison_dict = ValueComparisonDict(values=values_dict)

    # If list is invalid at top level, mark every index as invalid
    top_level_list_valid = checkpoint_results.get('valid', True)
    checkpoint_results_per_index: List[Dict] = [{
        'valid': top_level_list_valid
    }] * len(golden_list)
    for index_checkpoint_result in checkpoint_results.get('list_contents', []):
        list_index = index_checkpoint_result.get('list_index')
        try:
            checkpoint_results_per_index[list_index] = index_checkpoint_result
        except IndexError:
            continue

    if type_per_index:
        if content_type:
            comparison_dict.setdefault('errs', []).append(
                'Cannot specify both a content type and a type per index.')
        elif len(type_per_index) != len(golden_list):
            comparison_dict.setdefault('errs', []).append(
                'Type per index parameter does not match length of golden value.'
            )
        else:
            for i, golden_list_content in enumerate(golden_list):
                if type_per_index[i] == "INT":
                    values_dict[str(i)] = construct_int_field_raw_data(
                        golden_list_content,
                        str(extracted_list[i])
                        if isinstance(extracted_list, list) and
                        i < len(extracted_list) else None,
                        checkpoint_results=checkpoint_results_per_index[i])

                elif type_per_index[i] == "FLOAT":
                    values_dict[str(i)] = construct_float_field_raw_data(
                        golden_list_content,
                        str(extracted_list[i])
                        if isinstance(extracted_list, list) and
                        i < len(extracted_list) else None,
                        checkpoint_results=checkpoint_results_per_index[i])

                # if no type is specified, process as TEXT by default
                elif type_per_index[i] == "TEXT" or type_per_index[i] == None:
                    values_dict[str(i)] = construct_text_field_raw_data(
                        golden_list_content,
                        extracted_list[i]
                        if isinstance(extracted_list, list) and
                        i < len(extracted_list) else None,
                        checkpoint_results=checkpoint_results_per_index[i])
                else:
                    comparison_dict.setdefault('errs', []).append(
                        'Type per index parameter contains invalid types')
    elif content_type:
        if not isinstance(content_type, str):
            logging.info(
                "Error in constructing raw data: schema_content_type for a list field must be a str. Proceeding to ignore this parameter..."
            )
            content_type = None
        if content_type not in ['INT', 'FLOAT', 'TEXT']:
            comparison_dict.setdefault(
                'errs', []).append('Invalid contentType in golden schema.')
        elif content_type == 'INT':
            for i, golden_list_content in enumerate(golden_list):
                values_dict[str(i)] = construct_int_field_raw_data(
                    str(golden_list_content),
                    str(extracted_list[i])
                    if isinstance(extracted_list, list) and
                    i < len(extracted_list) else None,
                    checkpoint_results=checkpoint_results_per_index[i])
        elif content_type == 'FLOAT':
            for i, golden_list_content in enumerate(golden_list):
                values_dict[str(i)] = construct_float_field_raw_data(
                    str(golden_list_content),
                    str(extracted_list[i])
                    if isinstance(extracted_list, list) and
                    i < len(extracted_list) else None,
                    checkpoint_results=checkpoint_results_per_index[i])
        else:  # content_type == 'TEXT':
            for i, golden_list_content in enumerate(golden_list):
                values_dict[str(i)] = construct_text_field_raw_data(
                    golden_list_content,
                    extracted_list[i] if isinstance(extracted_list, list) and
                    i < len(extracted_list) else None,
                    checkpoint_results=checkpoint_results_per_index[i])
    else:  # if neither content_type nor type_per_index, all inner fields will be TEXT
        # print(golden_list)
        # print(extracted_list)
        for i, golden_list_content in enumerate(golden_list):
            values_dict[str(i)] = construct_text_field_raw_data(
                golden_list_content,
                extracted_list[i] if isinstance(extracted_list, list) and
                i < len(extracted_list) else None,
                checkpoint_results=checkpoint_results_per_index[i])

    if has_golden_type_err:
        comparison_dict.setdefault(
            'errs', []).append('Golden value could not be converted to list.')
    if has_extracted_type_err:
        comparison_dict.setdefault(
            'errs',
            []).append('Extracted value could not be converted to list.')
    return comparison_dict


def construct_int_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    has_golden_type_err = False
    golden_raw_data: Any = None
    if golden_value is not None and golden_value != '':
        try:
            golden_raw_data = int(golden_value)
        except ValueError:
            has_golden_type_err = True
            golden_raw_data = golden_value

    has_extracted_type_err = False
    extracted_raw_data: Any = None
    if extracted_value is not None and extracted_value != '':
        try:
            extracted_raw_data = int(extracted_value)
        except ValueError:
            has_extracted_type_err = True
            extracted_raw_data = extracted_value

    comparison_dict = ValueComparisonDict(
        golden_value=golden_raw_data,
        extracted_value=extracted_raw_data,
        was_flagged_for_review=checkpoint_results.get('valid', True) is False)
    if has_golden_type_err:
        comparison_dict.setdefault(
            'errs', []).append('Golden value could not be converted to int.')
    if has_extracted_type_err:
        comparison_dict.setdefault(
            'errs', []).append('Extracted value could not be converted to int.')
    return comparison_dict


def construct_float_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    # Because other parts of flow automatically round whole number floats to ints (e.g. 3.0 to 3)
    # we treat ints as valid floats, so to avoid difficult-to-trace type errors
    # empty fields are valid for numerical comparison and match other empty fields
    has_golden_type_err = False
    golden_raw_data: Any = None
    if golden_value is not None and golden_value != '':
        try:
            golden_raw_data = float(golden_value)
        except ValueError:
            has_golden_type_err = True
            golden_raw_data = golden_value

    has_extracted_type_err = False
    extracted_raw_data: Any = None
    if extracted_value is not None and extracted_value != '':
        try:
            extracted_raw_data = float(extracted_value)
        except ValueError:
            has_extracted_type_err = True
            extracted_raw_data = extracted_value

    comparison_dict = ValueComparisonDict(
        golden_value=golden_raw_data,
        extracted_value=extracted_raw_data,
        was_flagged_for_review=checkpoint_results.get('valid', True) is False)
    if has_golden_type_err:
        comparison_dict.setdefault(
            'errs', []).append('Golden value could not be converted to float.')
    if has_extracted_type_err:
        comparison_dict.setdefault(
            'errs',
            []).append('Extracted value could not be converted to float.')
    return comparison_dict


def construct_text_field_raw_data(
        golden_value: Text,
        extracted_value: Text,
        checkpoint_results: Dict = {}) -> ValueComparisonDict:
    # Cast golden and extracted to string if they are not None
    return ValueComparisonDict(
        golden_value=str(golden_value) if golden_value else golden_value,
        extracted_value=str(extracted_value)
        if extracted_value else extracted_value,
        was_flagged_for_review=checkpoint_results.get('valid', True) is False)


def generate_records_aggregated_by_field(raw_data: MergedRawDataDict) -> None:
    """
      In our merged data (passed in), we have fields aggregated by record.
      This method generates records aggregated by fields so we have a different perspective
      of our raw data.
      """
    # Generate records aggregated by field dictonary by scanning fields aggregated by record
    for class_label, class_dict in raw_data.copy()['classes'].items():
        fields_dict: Dict = defaultdict(list)
        for record in class_dict.get('records', []):
            record_id = record.get('name')
            for field_dict in record.get('fields', []):
                field_name = field_dict.get('name')
                record_dict = field_dict.copy()
                record_dict['name'] = record_id
                fields_dict[field_name].append(record_dict)
        fields_list = [
            MergedRawDataFieldDict(name=field_name, records=records_list)
            for field_name, records_list in fields_dict.items()
        ]
        raw_data['classes'][class_label]['fields'] = fields_list


def check_field_flagged_for_review(field_raw_data: ValueComparisonDict) -> bool:
    was_field_flagged_for_review = field_raw_data.get('was_flagged_for_review',
                                                      False)
    nested_values = field_raw_data.get('values', {}).values()
    for nested_raw_data in nested_values:
        was_field_flagged_for_review = was_field_flagged_for_review or check_field_flagged_for_review(
            nested_raw_data)

    return was_field_flagged_for_review


class AccuracyMetrics:

    def __init__(self) -> None:
        # Accuracy counts
        self.total = 0
        self.total_automated = 0
        self.total_automated_correct = 0
        self.total_human_review = 0
        self.total_human_review_correct = 0
        # Accuracy percents
        self.automation = 0.0
        self.automation_accuracy = 0.0
        self.human_review = 0.0
        self.human_review_accuracy = 0.0
        self.raw_fla = 0.0

    def compute_percent_fields(self) -> None:
        self.automation = safe_round_percent(self.total_automated * 100.0 /
                                             self.total) if self.total else 0.0
        self.automation_accuracy = safe_round_percent(
            self.total_automated_correct * 100.0 /
            self.total_automated,) if self.total_automated else 0.0
        self.human_review = safe_round_percent(
            self.total_human_review * 100.0 / self.total) if self.total else 0.0
        self.human_review_accuracy = safe_round_percent(
            self.total_human_review_correct * 100.0 /
            self.total_human_review) if self.total_human_review else 0.0
        self.raw_fla = safe_round_percent(
            (self.total_automated_correct + self.total_human_review_correct) *
            100.0 / self.total) if self.total else 0.0


class JobLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self) -> None:
        super(JobLevelAccuracyMetrics, self).__init__()
        self.total_records = 0
        self.total_records_flagged_for_review = 0
        self.total_splits = 0
        self.total_splits_correct = 0
        self.record_stp = 0.0
        self.split_classification_accuracy = 0.0
        self.classes: List[ClassLevelAccuracyMetrics] = []

    def compute_percent_fields(self) -> None:
        super(JobLevelAccuracyMetrics, self).compute_percent_fields()
        self.record_stp = 100 - safe_round_percent(
            self.total_records_flagged_for_review * 100.0 /
            self.total_records) if self.total_records else 0.0
        self.split_classification_accuracy = safe_round_percent(
            self.total_splits_correct * 100.0 /
            self.total_splits) if self.total_splits else 0.0


class ClassLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self, name: Text) -> None:
        super(ClassLevelAccuracyMetrics, self).__init__()
        # Class-level accuracy counts
        self.name = name
        self.total_records = 0
        self.total_records_classified_correctly = 0
        self.total_records_flagged_for_review = 0
        self.total_splits = 0
        self.total_splits_correct = 0
        # Class-level accuracy percents
        self.classification_accuracy = 0.0
        self.record_stp = 0.0
        self.split_classification_accuracy = 0.0

        self.field_metrics: Dict[Text, FieldLevelAccuracyMetrics] = {}
        self.record_metrics: Dict[Text, RecordLevelAccuracyMetrics] = {}

    def compute_percent_fields(self) -> None:
        super(ClassLevelAccuracyMetrics, self).compute_percent_fields()
        self.classification_accuracy = safe_round_percent(
            self.total_records_classified_correctly * 100.0 /
            self.total_records) if self.total_records else 0.0
        self.record_stp = 100 - safe_round_percent(
            self.total_records_flagged_for_review * 100.0 /
            self.total_records) if self.total_records else 0.0
        self.split_classification_accuracy = safe_round_percent(
            self.total_splits_correct * 100.0 /
            self.total_splits) if self.total_splits else 0.0


class RecordLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self) -> None:
        super(RecordLevelAccuracyMetrics, self).__init__()
        self.total_splits = 0
        self.total_splits_correct = 0
        self.split_classification_accuracy = 0.0

    def compute_percent_fields(self) -> None:
        super(RecordLevelAccuracyMetrics, self).compute_percent_fields()
        self.split_classification_accuracy = safe_round_percent(
            self.total_splits_correct * 100.0 /
            self.total_splits) if self.total_splits else 0.0


class FieldLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self) -> None:
        super().__init__()

    def get_nested_metrics(self) -> Dict[Text, Any]:
        return {}

    def set_nested_metrics(self, nested_metrics: Dict[Text, Any]) -> None:
        pass


class DictFieldLevelAccuracyMetrics(FieldLevelAccuracyMetrics):

    def __init__(self) -> None:
        super(DictFieldLevelAccuracyMetrics, self).__init__()
        self.dict_metrics: Dict[Text, Any] = {}

    def get_nested_metrics(self) -> Dict[Text, Any]:
        return self.dict_metrics

    def set_nested_metrics(self, dict_metrics: Dict[Text, Any]) -> None:
        self.dict_metrics = dict_metrics


class TableFieldLevelAccuracyMetrics(FieldLevelAccuracyMetrics):

    def __init__(self) -> None:
        super(TableFieldLevelAccuracyMetrics, self).__init__()
        self.table_metrics: Dict[Text, Dict[Text, Any]] = {
            'row_level': {},
            'col_level': {}
        }

    def get_nested_metrics(self) -> Dict[Text, Any]:
        return self.table_metrics


class ExtractedTablesListFieldLevelAccuracyMetrics(FieldLevelAccuracyMetrics):

    def __init__(self) -> None:
        super(ExtractedTablesListFieldLevelAccuracyMetrics, self).__init__()
        self.tables_metrics: Dict[Text, Dict[Text, Any]] = {}

    def get_nested_metrics(self) -> Dict[Text, Any]:
        return self.tables_metrics


class ListFieldLevelAccuracyMetrics(FieldLevelAccuracyMetrics):

    def __init__(self) -> None:
        super(ListFieldLevelAccuracyMetrics, self).__init__()
        self.list_metrics: Dict[Text, FieldLevelAccuracyMetrics] = {}

    def get_nested_metrics(self) -> Dict[Text, Any]:
        return self.list_metrics

    def set_nested_metrics(self, list_metrics: Dict[Text, Any]) -> None:
        self.list_metrics = list_metrics


def compute_num_matches(
        schema_type: Text,
        comparison_strategy: Dict[Text, Any],
        record: ValueComparisonDict,
        nested_field_metrics: Dict,
        was_classified_correctly: bool,
        content_type: Union[Text, Dict] = None,
        field_name: Text = '') -> Tuple[int, int, int, int, Dict]:
    """
    Helper function that routes lists, tables, and dicts to their own computation function.
    Returns a tuple of (total_fields, total_matches, nested_field_metrics)
    """
    if schema_type and (schema_type in [TABLE, EXTRACTED_TABLE]):
        return compute_table_num_matches(comparison_strategy, record,
                                         nested_field_metrics,
                                         was_classified_correctly, content_type)
    elif schema_type and schema_type == DICT:
        return compute_dict_num_matches(comparison_strategy, record,
                                        nested_field_metrics,
                                        was_classified_correctly, content_type)
    elif schema_type and schema_type == LIST:
        return compute_list_num_matches(comparison_strategy, record,
                                        nested_field_metrics,
                                        was_classified_correctly, content_type)
    elif schema_type and schema_type == EXTRACTED_TABLES_LIST:
        return compute_extracted_tables_list_num_matches(
            comparison_strategy, record, nested_field_metrics,
            was_classified_correctly, content_type)
    else:
        # print(schema_type)
        # print('leaf comparison')
        return compute_leaf_num_matches(schema_type, comparison_strategy,
                                        record, was_classified_correctly,
                                        field_name)


def compute_leaf_num_matches(
        schema_type: Text,
        comparison_strategy: Dict[Text, Any],
        record: ValueComparisonDict,
        was_classified_correctly: bool,
        field_name: Text = '') -> Tuple[int, int, int, int, Dict]:
    golden_value = record.get('golden_value')
    extracted_value = record.get('extracted_value')
    automated = not record.get('was_flagged_for_review', False)
    value_type_errs = record.get('errs')
    # Infer schema type of leaf field if unspecified
    # If either of the golden or extracted values types do not match the schema.json specified type for this field,
    # we mark this comparison as no match, and omit calling each enabled comparator.

    if value_type_errs:
        match = False
    else:
        schema_type = schema_type or TEXT
        # print(schema_type)
        # Get labels of comparators for the specified type
        comparator_labels = [
            label for label in comparators_by_type.get(schema_type, {})
        ]
        # Get fns and kwargs of comparators that are active for this type
        active_comparator_fns = [
            (comparators_by_type[schema_type][label]['fn'],
             comparison_strategy.get(label, {}).get('kwargs', {}))
            for label in comparator_labels
            if comparison_strategy.get(label, {}).get('active')
        ]
        match = golden_value == extracted_value
        print(str(golden_value) + " " + str(extracted_value) + " " + str(match))
        # print(active_comparator_fns)
        if was_classified_correctly:
            match = match or (not golden_value and not extracted_value)
        # OR the results of each comparator
        for comparator_fn, fn_kwargs in active_comparator_fns:
            if match:
                break
            # print(comparator_fn)
            comparator_result, err = comparator_fn(golden_value,
                                                   extracted_value, **fn_kwargs)
            print(
                str(golden_value) + " " + str(extracted_value) + " " +
                str(comparator_result))
            if err:
                record.setdefault('errs', []).append(err)
            match = match or comparator_result
    # if field_name == 'Receipt_Item_Details':
    #   print(str(record.get('name', '')) + " " + str(extracted_value) + " " + str(golden_value) + " " + str(match))
    record['is_match'] = bool(match)
    automated_fields = 1 if automated else 0
    automated_matches = 1 if automated and match else 0
    human_review_fields = 1 if not automated else 0
    human_review_matches = 1 if not automated and match else 0
    return automated_fields, automated_matches, human_review_fields, human_review_matches, {}


def compute_table_num_matches(
        comparison_strategy: Dict[Text, Any],
        record: ValueComparisonDict,
        nested_field_metrics: Dict,
        was_classified_correctly: bool,
        content_type: Union[Text,
                            Dict] = None) -> Tuple[int, int, int, int, Dict]:
    values = record.get('values')
    total_automated = 0
    total_automated_matches = 0
    total_human_review = 0
    total_human_review_matches = 0
    # Compute row-level and column-level accuracy metrics
    row_level_metrics = nested_field_metrics.get('row_level', {})
    col_level_metrics = nested_field_metrics.get('col_level', {})

    if not content_type:
        content_type = {}
    elif not isinstance(content_type, dict):
        logging.info(
            "Error in computing matches: content_type for a table field must be a dict. Proceeding to ignore this parameter..."
        )
        content_type = {}

    header_indices = []
    for row_idx, row_comparison_dict in values.items():
        row_idx_metrics = row_level_metrics.get(row_idx,
                                                FieldLevelAccuracyMetrics())
        for col_idx, col_comparison_dict in row_comparison_dict.get(
                'values', {}).items():
            if row_idx == "0":
                header_indices.append(col_comparison_dict.get("golden_value"))

            col_idx_metrics = col_level_metrics.get(col_idx,
                                                    FieldLevelAccuracyMetrics())

            leaf_type = content_type.get(header_indices[int(col_idx)])
            leaf_comparison_strategy = comparison_strategy.get(
                'headers', {}).get(header_indices[int(col_idx)], {})
            automated_cell_fields, automated_cell_matches, human_review_cell_fields, human_review_cell_matches, _ = compute_num_matches(
                leaf_type, leaf_comparison_strategy, col_comparison_dict, {},
                was_classified_correctly)
            # Increment row-level and column-level accuracy counts
            row_idx_metrics.total += (automated_cell_fields +
                                      human_review_cell_fields)
            col_idx_metrics.total += (automated_cell_fields +
                                      human_review_cell_fields)
            row_idx_metrics.total_automated += automated_cell_fields
            col_idx_metrics.total_automated += automated_cell_fields
            row_idx_metrics.total_automated_correct += automated_cell_matches
            col_idx_metrics.total_automated_correct += automated_cell_matches
            row_idx_metrics.total_human_review += human_review_cell_fields
            col_idx_metrics.total_human_review += human_review_cell_fields
            row_idx_metrics.total_human_review_correct += human_review_cell_matches
            col_idx_metrics.total_human_review_correct += human_review_cell_matches
            # Complete column-level metrics
            col_idx_metrics.compute_percent_fields()
            col_level_metrics[col_idx] = col_idx_metrics
            total_automated += automated_cell_fields
            total_automated_matches += automated_cell_matches
            total_human_review += human_review_cell_fields
            total_human_review_matches += human_review_cell_matches
        # Complete row-level metrics
        row_idx_metrics.compute_percent_fields()
        row_level_metrics[row_idx] = row_idx_metrics
    nested_field_metrics['row_level'] = row_level_metrics
    nested_field_metrics['col_level'] = col_level_metrics
    return total_automated, total_automated_matches, total_human_review, total_human_review_matches, nested_field_metrics


def compute_extracted_tables_list_num_matches(
        comparison_strategy: Dict[Text, Any],
        record: ValueComparisonDict,
        nested_field_metrics: Dict,
        was_classified_correctly: bool,
        content_type: Union[Text,
                            Dict] = None) -> Tuple[int, int, int, int, Dict]:
    values = record.get('values')
    total_automated = 0
    total_automated_matches = 0
    total_human_review = 0
    total_human_review_matches = 0

    if not content_type:
        content_type = {}
    elif not isinstance(content_type, dict):
        logging.info(
            "Error in computing matches: content_type for an extracted_tables_list field must be a dict. Proceeding to ignore this parameter..."
        )
        content_type = {}

    for table_idx, table_comparison_dict in values.items():
        table = {}
        header_indices = []
        row_level_metrics = nested_field_metrics.get(table_idx,
                                                     {}).get('row_level', {})
        table_level_metrics = FieldLevelAccuracyMetrics()
        for row_idx, row_comparison_dict in table_comparison_dict.get(
                'values', {}).items():
            col_level_metrics = nested_field_metrics.get(table_idx, {}).get(
                'col_level', {})
            row_idx_metrics = row_level_metrics.get(row_idx,
                                                    FieldLevelAccuracyMetrics())
            for col_idx, col_comparison_dict in row_comparison_dict.get(
                    'values', {}).items():
                if row_idx == "0":
                    header_indices.append(
                        col_comparison_dict.get("golden_value"))

                col_idx_metrics = col_level_metrics.get(
                    col_idx, FieldLevelAccuracyMetrics())

                try:
                    table_leaf_type = content_type.get('tables',
                                                       [])[int(table_idx)]
                    table_comparison_strategy = comparison_strategy.get(
                        'tables', [])[int(table_idx)]
                except IndexError:
                    table_comparison_strategy = {}
                    table_leaf_type = {}
                leaf_type = table_leaf_type.get(header_indices[int(col_idx)])
                leaf_comparison_strategy = table_comparison_strategy.get(
                    'headers', {}).get(header_indices[int(col_idx)], {})
                automated_cell_fields, automated_cell_matches, human_review_cell_fields, human_review_cell_matches, _ = compute_num_matches(
                    leaf_type, leaf_comparison_strategy, col_comparison_dict,
                    {}, was_classified_correctly)
                # Increment row-level and column-level accuracy counts
                row_idx_metrics.total += (automated_cell_fields +
                                          human_review_cell_fields)
                col_idx_metrics.total += (automated_cell_fields +
                                          human_review_cell_fields)
                table_level_metrics.total += (automated_cell_fields +
                                              human_review_cell_fields)
                row_idx_metrics.total_automated += automated_cell_fields
                col_idx_metrics.total_automated += automated_cell_fields
                table_level_metrics.total_automated += automated_cell_fields
                row_idx_metrics.total_automated_correct += automated_cell_matches
                col_idx_metrics.total_automated_correct += automated_cell_matches
                table_level_metrics.total_automated_correct += automated_cell_matches
                row_idx_metrics.total_human_review += human_review_cell_fields
                col_idx_metrics.total_human_review += human_review_cell_fields
                table_level_metrics.total_human_review += human_review_cell_fields
                row_idx_metrics.total_human_review_correct += human_review_cell_matches
                col_idx_metrics.total_human_review_correct += human_review_cell_matches
                table_level_metrics.total_human_review_correct += human_review_cell_matches
                # Complete column-level metrics
                col_idx_metrics.compute_percent_fields()
                col_level_metrics[col_idx] = col_idx_metrics
                total_automated += automated_cell_fields
                total_automated_matches += automated_cell_matches
                total_human_review += human_review_cell_fields
                total_human_review_matches += human_review_cell_matches
            # Complete row-level metrics
            row_idx_metrics.compute_percent_fields()
            row_level_metrics[row_idx] = row_idx_metrics
            # overwrite table metrics each loop so they are accessible for the loads at the top of the loop
            table['col_level'] = col_level_metrics
            table['row_level'] = row_level_metrics
            table['table_level'] = table_level_metrics
            nested_field_metrics[str(table_idx)] = table

    return total_automated, total_automated_matches, total_human_review, total_human_review_matches, nested_field_metrics


def compute_dict_num_matches(
        comparison_strategy: Dict[Text, Any],
        record: ValueComparisonDict,
        nested_field_metrics: Dict,
        was_classified_correctly: bool,
        content_type: Union[Text,
                            Dict] = None) -> Tuple[int, int, int, int, Dict]:
    leaf_type = None
    if content_type:
        if not isinstance(content_type, str):
            logging.info(
                "Error in computing matches: content_type for a dict field must be a str. Proceeding to ignore this parameter..."
            )
            content_type = None
        leaf_type = content_type
    values = record.get('values')
    # Base for recursion. We want to find the leaf values of dictionaries and work our way out to get nested level metrics.
    if not values:
        return compute_num_matches(leaf_type, comparison_strategy, record, {},
                                   was_classified_correctly)
    total_automated = 0
    total_automated_matches = 0
    total_human_review = 0
    total_human_review_matches = 0
    # Compute key's accuracy metrics
    for key, comparison_dict in values.items():
        key_metrics = nested_field_metrics.get(key,
                                               DictFieldLevelAccuracyMetrics())
        total_automated_nested_fields, total_automated_nested_matches, total_human_review_nested_fields, total_human_review_nested_matches, key_nested_field_metrics = compute_dict_num_matches(
            comparison_strategy, comparison_dict,
            key_metrics.get_nested_metrics(), was_classified_correctly,
            leaf_type)
        if key_nested_field_metrics:
            key_metrics.set_nested_metrics(key_nested_field_metrics)
        # Increment key's accuracy counts
        key_metrics.total += (total_automated_nested_fields +
                              total_human_review_nested_fields)
        key_metrics.total_automated += total_automated_nested_fields
        key_metrics.total_automated_correct += total_automated_nested_matches
        key_metrics.total_human_review += total_human_review_nested_fields
        key_metrics.total_human_review_correct += total_human_review_nested_matches
        # Complete key's accuracy metrics
        key_metrics.compute_percent_fields()
        nested_field_metrics[key] = key_metrics
        total_automated += total_automated_nested_fields
        total_automated_matches += total_automated_nested_matches
        total_human_review += total_human_review_nested_fields
        total_human_review_matches += total_human_review_nested_matches
    return total_automated, total_automated_matches, total_human_review, total_human_review_matches, nested_field_metrics


def compute_list_num_matches(
        comparison_strategy: Dict[Text, Any],
        record: ValueComparisonDict,
        nested_field_metrics: Dict,
        was_classified_correctly: bool,
        content_type: Union[Text,
                            Dict] = None) -> Tuple[int, int, int, int, Dict]:
    values = record.get('values')
    total_automated = 0
    total_automated_matches = 0
    total_human_review = 0
    total_human_review_matches = 0
    # Compute each index's accuracy metrics
    leaf_type = None
    if content_type:
        if not isinstance(content_type, str):
            logging.info(
                "Error in computing matches: content_type for a list field must be a str. Proceeding to ignore this parameter..."
            )
            content_type = None
        leaf_type = content_type
    for list_idx, comparison_dict in values.items():
        automated_list_idx_fields, automated_list_idx_matches, human_review_list_idx_fields, human_review_list_idx_matches, _ = compute_num_matches(
            leaf_type, comparison_strategy, comparison_dict, {},
            was_classified_correctly)
        list_index_metrics = nested_field_metrics.get(
            list_idx, FieldLevelAccuracyMetrics())
        # Increment index accuracy counts
        list_index_metrics.total += (automated_list_idx_fields +
                                     human_review_list_idx_fields)
        list_index_metrics.total_automated += automated_list_idx_fields
        total_automated_matches += automated_list_idx_matches
        list_index_metrics.total_automated_correct += automated_list_idx_matches
        list_index_metrics.total_human_review += human_review_list_idx_fields
        total_human_review_matches += human_review_list_idx_matches
        list_index_metrics.total_human_review_correct += human_review_list_idx_matches
        # Complete index accuracy metrics
        list_index_metrics.compute_percent_fields()
        total_automated += automated_list_idx_fields
        total_human_review += human_review_list_idx_fields
        nested_field_metrics[list_idx] = list_index_metrics
    return total_automated, total_automated_matches, total_human_review, total_human_review_matches, nested_field_metrics


def compute_record_and_field_level_metrics(
    comparison_logic: ComparisonLogicClassDict,
    class_raw_data: MergedRawDataClassDict,
    exempt_misclassified_records: bool = False
) -> Tuple[Dict[Text, RecordLevelAccuracyMetrics], Dict[
        Text, FieldLevelAccuracyMetrics]]:
    # Dictionary to keep track of record-level accuracy
    record_level_metrics: Dict[Text, RecordLevelAccuracyMetrics] = defaultdict(
        RecordLevelAccuracyMetrics)
    field_level_metrics: Dict[Text, FieldLevelAccuracyMetrics] = defaultdict(
        FieldLevelAccuracyMetrics)

    for record_with_pages in class_raw_data['records']:
        record_id = record_with_pages['name']
        pages = record_with_pages['pages']
        for page in pages:
            record_level_metrics[record_id].total_splits += 1
            if page['is_match']:
                record_level_metrics[record_id].total_splits_correct += 1

    classified_correctly = set()
    for record_dict in class_raw_data['records']:
        if record_dict['was_classified_correctly']:
            classified_correctly.add(record_dict['name'])

    for field in class_raw_data['fields']:
        field_name = field['name']
        # Counters to keep track of field-level accuracy
        schema_type = comparison_logic['fields'][field_name]['type']
        comparison_strategy = comparison_logic['fields'][field_name][
            'comparisonStrategy']
        print(field_name + " " + str(comparison_strategy))
        field_metrics = FieldLevelAccuracyMetrics()
        if schema_type and (schema_type == TABLE or
                            schema_type == EXTRACTED_TABLE):
            field_metrics = TableFieldLevelAccuracyMetrics()
        elif schema_type and schema_type == DICT:
            field_metrics = DictFieldLevelAccuracyMetrics()
        elif schema_type and schema_type == LIST:
            field_metrics = ListFieldLevelAccuracyMetrics()
        elif schema_type and schema_type == EXTRACTED_TABLES_LIST:
            field_metrics = ExtractedTablesListFieldLevelAccuracyMetrics()
        for record in field['records']:
            record_id = record['name']
            was_classified_correctly = record_id in classified_correctly
            if exempt_misclassified_records and not was_classified_correctly:
                continue

            # Compute total matches for each field
            # Each field may have nested matches, leading to more than 1 match per top-level field. We leverage compute_num_matches
            # to scan the nested raw data and build a similarly nested metrics dict.
            total_automated_within_field, total_automated_correct_within_field, total_human_review_within_field, total_human_review_correct_within_field, nested_metrics = compute_num_matches(
                schema_type, comparison_strategy, record,
                field_metrics.get_nested_metrics(), was_classified_correctly,
                comparison_logic['fields'][field_name].get('contentType'),
                field_name)
            field_metrics.set_nested_metrics(nested_metrics)

            # Increment field-level and record-level accuracy counters
            field_metrics.total += (total_automated_within_field +
                                    total_human_review_within_field)
            record_level_metrics[record_id].total += (
                total_automated_within_field + total_human_review_within_field)
            field_metrics.total_automated += total_automated_within_field
            field_metrics.total_automated_correct += total_automated_correct_within_field
            record_level_metrics[
                record_id].total_automated += total_automated_within_field
            record_level_metrics[
                record_id].total_automated_correct += total_automated_correct_within_field
            field_metrics.total_human_review += total_human_review_within_field
            field_metrics.total_human_review_correct += total_human_review_correct_within_field
            record_level_metrics[
                record_id].total_human_review += total_human_review_within_field
            record_level_metrics[
                record_id].total_human_review_correct += total_human_review_correct_within_field
        # Complete field-level accuracy metrics
        field_metrics.compute_percent_fields()
        field_level_metrics[field_name] = field_metrics

    # Complete record-level accuracy metrics
    for record_id, record_accuracy_metrics in record_level_metrics.items():
        record_accuracy_metrics.compute_percent_fields()
    return record_level_metrics, field_level_metrics


def generate_fields_aggregated_by_record(raw_data: MergedRawDataDict) -> None:
    """
      When we compute accuracy metrics, we iterate through records aggregated by field
      in order to determine whether the golden and extracted values match. We then persist a
      boolean flag 'is_match' onto the resulting comparison dictionary.
      This method regenerates fields aggregated by record so that the is_match flag exists on
      both aggregations.
      """
    # Generate records aggregated by field dictonary by scanning fields aggregated by record
    for class_label, class_dict in raw_data.copy()['classes'].items():
        was_classified_correctly_dict: Dict[Text, bool] = {}
        was_flagged_for_review_dict: Dict[Text, bool] = {}
        pages_dict: Dict[Text, List[PageComparisonDict]] = {}
        for record in class_dict.get('records', []):
            was_classified_correctly_dict[
                record['name']] = record['was_classified_correctly']
            was_flagged_for_review_dict[
                record['name']] = record['was_flagged_for_review']
            pages_dict[record['name']] = record.get('pages', [])
        records_dict: Dict = defaultdict(list)
        for field in class_dict.get('fields', []):
            field_name = field.get('name')
            for record_dict in field.get('records', []):
                record_id = record_dict.get('name')
                field_dict = record_dict.copy()
                field_dict['name'] = field_name
                records_dict[record_id].append(field_dict)
        records_list = [
            MergedRawDataRecordDict(
                name=record_id,
                fields=fields_list,
                was_classified_correctly=was_classified_correctly_dict.get(
                    record_id, False),
                was_flagged_for_review=was_flagged_for_review_dict.get(
                    record_id, False),
                pages=pages_dict.get(record_id, []))
            for record_id, fields_list in records_dict.items()
        ]
        raw_data['classes'][class_label]['records'] = records_list


def safe_round_percent(x: float) -> float:
    """
  when rounding percentages, do not return 100 or 0 unless those are the true values
  """
    if x >= 100 or x <= 0:
        return round(x, 1)
    if x >= 99.9:
        return 99.9
    if x <= 0.1:
        return 0.1
    return round(x, 1)

    def compute_percent_fields(self) -> None:
        self.automation = safe_round_percent(self.total_automated * 100.0 /
                                             self.total) if self.total else 0.0
        self.automation_accuracy = safe_round_percent(
            self.total_automated_correct * 100.0 /
            self.total_automated,) if self.total_automated else 0.0
        self.human_review = safe_round_percent(
            self.total_human_review * 100.0 / self.total) if self.total else 0.0
        self.human_review_accuracy = safe_round_percent(
            self.total_human_review_correct * 100.0 /
            self.total_human_review) if self.total_human_review else 0.0
        self.raw_fla = safe_round_percent(
            (self.total_automated_correct + self.total_human_review_correct) *
            100.0 / self.total) if self.total else 0.0


class JobLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self) -> None:
        super(JobLevelAccuracyMetrics, self).__init__()
        self.total_records = 0
        self.total_records_flagged_for_review = 0
        self.total_splits = 0
        self.total_splits_correct = 0
        self.record_stp = 0.0
        self.split_classification_accuracy = 0.0
        self.classes: List[ClassLevelAccuracyMetrics] = []

    def compute_percent_fields(self) -> None:
        super(JobLevelAccuracyMetrics, self).compute_percent_fields()
        self.record_stp = 100 - safe_round_percent(
            self.total_records_flagged_for_review * 100.0 /
            self.total_records) if self.total_records else 0.0
        self.split_classification_accuracy = safe_round_percent(
            self.total_splits_correct * 100.0 /
            self.total_splits) if self.total_splits else 0.0


class FieldLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self) -> None:
        super(FieldLevelAccuracyMetrics, self).__init__()

    def get_nested_metrics(self) -> Dict[Text, Any]:
        return {}

    def set_nested_metrics(self, nested_metrics: Dict[Text, Any]) -> None:
        pass


class RecordLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self) -> None:
        super(RecordLevelAccuracyMetrics, self).__init__()
        self.total_splits = 0
        self.total_splits_correct = 0
        self.split_classification_accuracy = 0.0

    def compute_percent_fields(self) -> None:
        super(RecordLevelAccuracyMetrics, self).compute_percent_fields()
        self.split_classification_accuracy = safe_round_percent(
            self.total_splits_correct * 100.0 /
            self.total_splits) if self.total_splits else 0.0


class ClassLevelAccuracyMetrics(AccuracyMetrics):

    def __init__(self, name: Text) -> None:
        super(ClassLevelAccuracyMetrics, self).__init__()
        # Class-level accuracy counts
        self.name = name
        self.total_records = 0
        self.total_records_classified_correctly = 0
        self.total_records_flagged_for_review = 0
        self.total_splits = 0
        self.total_splits_correct = 0
        # Class-level accuracy percents
        self.classification_accuracy = 0.0
        self.record_stp = 0.0
        self.split_classification_accuracy = 0.0

        self.field_metrics: Dict[Text, FieldLevelAccuracyMetrics] = {}
        self.record_metrics: Dict[Text, RecordLevelAccuracyMetrics] = {}

    def compute_percent_fields(self) -> None:
        super(ClassLevelAccuracyMetrics, self).compute_percent_fields()
        self.classification_accuracy = safe_round_percent(
            self.total_records_classified_correctly * 100.0 /
            self.total_records) if self.total_records else 0.0
        self.record_stp = 100 - safe_round_percent(
            self.total_records_flagged_for_review * 100.0 /
            self.total_records) if self.total_records else 0.0
        self.split_classification_accuracy = safe_round_percent(
            self.total_splits_correct * 100.0 /
            self.total_splits) if self.total_splits else 0.0
