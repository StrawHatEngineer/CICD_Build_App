from typing import Any, Dict, Text, Tuple
from mypy_extensions import TypedDict

from .consts import DIFFED_FIELDS

DiffObject = TypedDict('DiffObject', {
    'val1': float,
    'val2': float,
    'diff': float
})


def create_diff_object(val1: float, val2: float) -> DiffObject:
    return DiffObject(val1=val1, val2=val2, diff=round((val1 - val2), 1))


def add_diff_fields(target_dict: Dict[Text, Any], metrics1: Dict[Text, float],
                    metrics2: Dict[Text, float]) -> None:
    for field_name in DIFFED_FIELDS:
        target_dict[field_name] = create_diff_object(metrics1[field_name],
                                                     metrics2[field_name])


def add_list_metrics(list_metrics_diff: Dict[Text, Any], list1: Dict[Text, Any],
                     list2: Dict[Text, Any]) -> None:
    for idx in list1.keys():
        # assume that lists will be the same length, but if they are not just skip trailing indices
        if idx not in list2.keys():
            continue
        list_metrics_diff[idx] = {}
        add_diff_fields(list_metrics_diff[idx], list1[idx], list2[idx])


def add_table_metrics(table_metrics_diff: Dict[Text, Any],
                      table1: Dict[Text, Any], table2: Dict[Text, Any]) -> None:
    table_metrics_diff['row_level'] = {}
    table_metrics_diff['col_level'] = {}

    # no checking for keyerror here, row level and col level absent is an acceptable runtime error
    add_list_metrics(table_metrics_diff['row_level'], table1['row_level'],
                     table2['row_level'])

    add_list_metrics(table_metrics_diff['col_level'], table1['col_level'],
                     table2['col_level'])


def add_dict_metrics(dict_metrics_diff: Dict[Text, Any], dict1: Dict[Text, Any],
                     dict2: Dict[Text, Any]) -> None:
    """
  add diffs for dict metrics
  acceptable nested fields inside a dictionary are lists and nested dicts
  nested dicts can themselves contain lists and dicts
  """
    for key in dict1.keys():
        # only record a diff if the key is present in both dictionaries
        if key not in dict2:
            continue

        # we automatically add a dict metrics field to each inner dict
        # skip empty instances of this object
        if key == 'dict_metrics' and dict1[key] == {}:
            continue

        inner1 = dict1[key]
        inner2 = dict2[key]
        dict_metrics_diff[key] = {}
        add_diff_fields(dict_metrics_diff[key], inner1, inner2)

        if 'list_metrics' in inner1 and len(inner1['list_metrics']) > 0:
            dict_metrics_diff[key]['list_metrics'] = {}
            add_list_metrics(dict_metrics_diff[key]['list_metrics'],
                             inner1['list_metrics'], inner2['list_metrics'])

        if 'dict_metrics' in inner1 and len(inner1['dict_metrics']) > 0:
            dict_metrics_diff[key]['dict_metrics'] = {}
            add_dict_metrics(dict_metrics_diff[key]['dict_metrics'],
                             inner1['dict_metrics'], inner2['dict_metrics'])


def add_field_level(field_metrics_diff: Dict[Text, Any],
                    field_metrics1: Dict[Text, Any],
                    field_metrics2: Dict[Text, Any]) -> Text:
    """
  add diff for everything inside the field_metrics map to 'field_diff'
  """
    for field_name in field_metrics1.keys():
        if field_name not in field_metrics2.keys():
            msg = 'field {} not found in second accuracy metrics'.format(
                field_name)
            return msg

        field1 = field_metrics1[field_name]
        field2 = field_metrics2[field_name]

        # add the current field to the field
        cur_field_diff: Dict[Text, Any] = {}
        field_metrics_diff[field_name] = cur_field_diff
        add_diff_fields(cur_field_diff, field1, field2)

        # if this field is a list
        if 'list_metrics' in field1 and isinstance(field1['list_metrics'],
                                                   dict):
            list_metrics1 = field1['list_metrics']
            list_metrics2 = field2['list_metrics']
            cur_field_diff['list_metrics'] = {}
            add_list_metrics(cur_field_diff['list_metrics'], list_metrics1,
                             list_metrics2)

        # if this field is a dict
        if 'dict_metrics' in field1 and isinstance(field1['dict_metrics'],
                                                   dict):
            dict_metrics1 = field1['dict_metrics']
            dict_metrics2 = field2['dict_metrics']
            cur_field_diff['dict_metrics'] = {}
            add_dict_metrics(cur_field_diff['dict_metrics'], dict_metrics1,
                             dict_metrics2)

        # if this field is a table
        if 'table_metrics' in field1 and isinstance(field1['table_metrics'],
                                                    dict):
            table_metrics1 = field1['table_metrics']
            table_metrics2 = field2['table_metrics']
            cur_field_diff['table_metrics'] = {}
            add_table_metrics(cur_field_diff['table_metrics'], table_metrics1,
                              table_metrics2)

    return None


def add_record_level(record_metrics_diff: Dict[Text, Any],
                     record_metrics1: Dict[Text, Any],
                     record_metrics2: Dict[Text, Any]) -> Text:
    for record_name in record_metrics1.keys():
        if record_name not in record_metrics2:
            msg = 'record {} not found in second accuracy metrics'.format(
                record_name)
            return msg

        record1 = record_metrics1[record_name]
        record2 = record_metrics2[record_name]

        # add the current field to the field
        cur_record_diff: Dict[Text, Any] = {}
        record_metrics_diff[record_name] = cur_record_diff
        add_diff_fields(cur_record_diff, record1, record2)

    return None


def build_metrics_diff(
        metrics1: Dict[Text, Any],
        metrics2: Dict[Text, Any]) -> Tuple[Dict[Text, Any], Text]:
    """
  given two metrics.json maps, construct and return the difference between the two
  """
    metrics_diff: Dict[Text, Any] = {}

    # diff top-level metrics for whole run
    add_diff_fields(metrics_diff, metrics1, metrics2)

    metrics_diff['classes'] = []
    for class_dict1 in metrics1['classes']:
        classname = class_dict1['name']
        search_list = [d for d in metrics2['classes'] if d['name'] == classname]
        if len(search_list) != 1:
            msg = '{} classes found named {} in second accuracy metrics'.format(
                len(search_list), classname)
            return None, msg
        class_dict2 = search_list[0]

        # add a dictionary for this class to the metrics diff
        class_diff = {}
        class_diff['name'] = classname

        # classification accuracy needs to be added manually because it only exists at this level
        classification_accuracy_diff = create_diff_object(
            class_dict1['classification_accuracy'],
            class_dict2['classification_accuracy'])
        class_diff['classification_accuracy'] = classification_accuracy_diff

        metrics_diff['classes'].append(class_diff)

        # diff class-level metrics
        add_diff_fields(class_diff, class_dict1, class_dict2)
        class_diff['field_metrics'] = {}
        err = add_field_level(class_diff['field_metrics'],
                              class_dict1['field_metrics'],
                              class_dict2['field_metrics'])
        if err:
            return None, err

        class_diff['record_metrics'] = {}
        err = add_record_level(class_diff['record_metrics'],
                               class_dict1['record_metrics'],
                               class_dict2['record_metrics'])
        if err:
            return None, err

    return metrics_diff, None
