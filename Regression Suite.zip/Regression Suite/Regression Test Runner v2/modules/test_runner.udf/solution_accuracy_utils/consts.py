# Goldens directory consts
GOLDENS_DIR_NAME = 'goldens'
GOLDEN_DATA_EXCEL_FILE_NAME = 'data.xlsx'
GOLDEN_TABLES_EXCEL_FILE_NAME = 'tables.xlsx'
GOLDEN_PAGE_SPLITS_EXCEL_FILE_NAME = 'page_splits.xlsx'
SCHEMA_FILE_NAME = 'schema.json'
GOLDEN_REGISTRY_FILE_NAME = 'registry.json'
# Accuracy directory consts
ACCURACY_DIR_NAME = 'accuracy'
METRICS_FILE_NAME = 'metrics.json'
RAW_DATA_FILE_NAME_TEMPLATE = 'raw_data_{}.json'
RECORD_METADATA_FILE_NAME = 'record_metadata.json'
# Data types
DICT = 'DICT'
FLOAT = 'FLOAT'
INT = 'INT'
LIST = 'LIST'
OBJECT_LIST = 'OBJECT_LIST'
TEXT_LIST = 'TEXT_LIST'
TABLE = 'TABLE'
TEXT = 'TEXT'
EXTRACTED_TABLE = 'EXTRACTED_TABLE'
EXTRACTED_TABLES_LIST = 'EXTRACTED_TABLES_LIST'

NESTED_FIELDS = [
    TABLE, DICT, LIST, EXTRACTED_TABLE, EXTRACTED_TABLES_LIST, TEXT_LIST,
    OBJECT_LIST
]

# only diff percentages, don't worry about absolute totals
DIFFED_FIELDS = [
    'automation', 'automation_accuracy', 'human_review',
    'human_review_accuracy', 'raw_fla'
]

# AIHub solution accuracy constants
AIHUB_DEFAULT_CLASS_NAME = 'DEFAULT_CLASS_NAME'
