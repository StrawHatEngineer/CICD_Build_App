import pandas as pd
from difflib import SequenceMatcher
from typing import Dict, Any, Optional, Tuple, List
from dateutil.parser import parse
import logging


class TableComparator:

    def __init__(self, match_config: Dict[str, Dict[str, Any]]):
        """
        Initialize TableComparator with matching configuration.
        
        Args:
            match_config: Dictionary specifying matching rules for columns
            Example:
            {
                "column1": {"exact_match": True},
                "column2": {"exact_match": False, "threshold": 0.9}
            }
        """
        self.match_config = match_config
        self.DEFAULT_CONFIG = {'exact_match': True, 'threshold': 0.9}

    def normalize_value(self, value: Any) -> str:
        """Normalize values for comparison."""
        if pd.isna(value):
            return ""

        # Convert to string and normalize
        value = str(value).strip().lower()

        # Handle numeric values
        try:
            new_value = str(float(value.replace(',', '')))
            return value
        except Exception:
            pass

        # Handle dates
        try:
            return parse(value, fuzzy=False).strftime('%Y-%m-%d')
        except Exception:
            pass

        return value

    def preprocess_table(self,
                         df: pd.DataFrame,
                         key_columns: Optional[list] = None,
                         is_extracted: bool = False,
                         golden_columns: Optional[list] = None) -> pd.DataFrame:
        """
        Preprocess table by normalizing values and handling missing columns.
        
        Args:
            df: DataFrame to preprocess
            key_columns: List of key columns for matching
            is_extracted: Whether this is the extracted DataFrame
            golden_columns: List of columns from golden DataFrame (needed for extracted DataFrame)
        """
        df = df.copy()

        # Add missing key columns if specified
        if key_columns:
            for col in key_columns:
                if col not in df.columns:
                    df[col] = ""

        # For extracted DataFrame, add missing columns from golden
        if is_extracted and golden_columns:
            for col in golden_columns:
                if col not in df.columns:
                    df[col] = ""  # Add missing columns with empty values

        # Normalize all values
        for col in df.columns:
            df[col] = df[col].apply(self.normalize_value)

        return df.reset_index(drop=True)

    def calculate_row_match_score(
            self,
            golden_row: pd.Series,
            extracted_row: pd.Series,
            key_columns: Optional[List[str]] = None) -> Tuple[int, float]:
        """
        Calculate matching score between two rows with key column weighting.
        All columns in golden_row must be scored, even if missing in extracted_row.
        """
        matching_cells = 0
        weighted_score = 0
        total_weight = 0

        for col in golden_row.index:
            # Assign higher weight to key columns
            weight = 3.0 if key_columns and col in key_columns else 1.0
            total_weight += weight

            val1 = golden_row[col]
            val2 = extracted_row.get(
                col, "")  # Default to empty string if column missing

            config = self.match_config.get(col, self.DEFAULT_CONFIG)

            if config['exact_match']:
                if val1 == val2:
                    matching_cells += 1
                    weighted_score += weight
            else:
                # Fuzzy matching
                similarity = (1.0 if val1 == val2 else
                              0.0 if not val1 or not val2 else SequenceMatcher(
                                  None, val1, val2).ratio())
                if similarity >= config.get('threshold', 0.9):
                    matching_cells += 1
                    weighted_score += weight * similarity

        normalized_score = weighted_score / total_weight if total_weight > 0 else 0
        return matching_cells, normalized_score

    def find_best_matches(
            self,
            golden_df: pd.DataFrame,
            extracted_df: pd.DataFrame,
            key_columns: Optional[list] = None,
            ignore_extra_columns: bool = False,
            ignore_extra_rows: bool = False) -> Tuple[float, Dict[str, Any]]:
        """
        Find best matches considering all possible combinations and handling missing columns.
        """
        # Preprocess golden table first
        golden = self.preprocess_table(golden_df, key_columns)
        golden_columns = golden.columns.tolist()

        # Preprocess extracted table with knowledge of golden columns
        extracted = self.preprocess_table(extracted_df,
                                          key_columns,
                                          is_extracted=True,
                                          golden_columns=golden_columns)

        if ignore_extra_columns:
            # Keep only golden columns in extracted DataFrame
            extracted = extracted[golden_columns]

        # Store all possible matches and their scores
        all_possible_matches = []

        # Calculate scores for all possible combinations
        for golden_idx, golden_row in golden.iterrows():
            row_matches = []

            for ext_idx, extracted_row in extracted.iterrows():
                # First check key columns if specified
                key_columns_match = True
                if key_columns:
                    key_columns_match = all(
                        golden_row[col] == extracted_row[col]
                        for col in key_columns
                        if self.match_config.get(
                            col, self.DEFAULT_CONFIG)['exact_match'])

                matching_cells, weighted_score = self.calculate_row_match_score(
                    golden_row, extracted_row, key_columns)

                # Boost score if key columns match
                if key_columns and key_columns_match:
                    weighted_score *= 1.5  # Boost factor for key column matches

                row_matches.append({
                    'golden_idx':
                        golden_idx,
                    'extracted_idx':
                        ext_idx,
                    'matching_cells':
                        matching_cells,
                    'weighted_score':
                        weighted_score,
                    'total_cells':
                        len(golden_row),
                    'key_columns_match':
                        key_columns_match if key_columns else False
                })

            all_possible_matches.extend(row_matches)

        # Sort all matches by weighted score and key column matches
        all_possible_matches.sort(key=lambda x:
                                  (x['key_columns_match'], x['weighted_score']),
                                  reverse=True)

        # Track assigned rows
        matched_golden_rows = set()
        matched_extracted_rows = set()
        final_matches = []

        # Assign best matches globally
        for match in all_possible_matches:
            golden_idx = match['golden_idx']
            extracted_idx = match['extracted_idx']

            # Skip if either row is already matched
            if golden_idx in matched_golden_rows or extracted_idx in matched_extracted_rows:
                continue

            final_matches.append(match)
            matched_golden_rows.add(golden_idx)
            matched_extracted_rows.add(extracted_idx)

        # Prepare match information
        matches_info = {
            'matched_pairs':
                final_matches,
            'unmatched_golden_rows':
                list(set(range(len(golden))) - matched_golden_rows),
            'unmatched_extracted_rows':
                list(set(range(len(extracted))) - matched_extracted_rows),
            'missing_columns': [
                col for col in golden_columns if col not in extracted_df.columns
            ]
        }

        # Calculate accuracy
        total_matched_cells = sum(
            pair['matching_cells'] for pair in matches_info['matched_pairs'])
        total_cells = len(golden) * len(golden.columns)

        # Add penalty for unmatched extracted rows if not ignored
        if not ignore_extra_rows:
            total_cells += len(matches_info['unmatched_extracted_rows']) * len(
                golden.columns)

        accuracy = (total_matched_cells / total_cells *
                    100) if total_cells > 0 else 0.0

        return accuracy, matches_info

    def get_aligned_extracted_data_2d(
            self,
            golden_data: List[List[Any]],
            extracted_data: List[List[Any]],
            key_columns: Optional[list] = None,
            ignore_extra_columns: bool = False,
            ignore_extra_rows: bool = False) -> List[List[Any]]:
        """
        Aligns extracted 2D array data with golden 2D array data based on matching rows.
        Preserves original cell values from extracted data.
        
        Args:
            golden_data: Reference 2D array with header row
            extracted_data: 2D array to be aligned with header row
            key_columns: Optional list of column names to prioritize in matching
            ignore_extra_columns: Whether to ignore columns not in golden data
            ignore_extra_rows: Whether to ignore rows not matched in extracted data
            
        Returns:
            List[List[Any]]: Aligned extracted data as 2D array with header row
        """
        if not golden_data or not extracted_data:
            return []

        # Store original extracted data in a dictionary for later use
        extracted_headers = extracted_data[0]
        original_extracted_rows = []
        for row in extracted_data[1:]:
            row_dict = {
                header: value for header, value in zip(extracted_headers, row)
            }
            original_extracted_rows.append(row_dict)

        # Convert 2D arrays to DataFrames for matching
        golden_headers = golden_data[0]

        golden_df = pd.DataFrame(golden_data[1:], columns=golden_headers)
        extracted_df = pd.DataFrame(extracted_data[1:],
                                    columns=extracted_headers)

        # Print information about ignored columns
        extra_columns = [
            col for col in extracted_headers if col not in golden_headers
        ]
        if extra_columns and ignore_extra_columns:
            logging.info("\n=== IGNORED COLUMNS ===")
            logging.info(
                f"The following columns from extracted data are being ignored: {extra_columns}"
            )

        # Get matches using existing method
        _, matches_info = self.find_best_matches(golden_df, extracted_df,
                                                 key_columns,
                                                 ignore_extra_columns,
                                                 ignore_extra_rows)

        # Print information about ignored rows
        if matches_info['unmatched_extracted_rows'] and ignore_extra_rows:
            logging.info("\n=== IGNORED ROWS ===")
            logging.info(
                f"Ignoring {len(matches_info['unmatched_extracted_rows'])} extra rows from extracted data"
            )
            logging.info("Row content being ignored:")
            for idx in matches_info['unmatched_extracted_rows']:
                row_content = original_extracted_rows[idx]
                logging.info(f"  Row {idx}: {row_content}")

        # Initialize result array with header row
        num_golden_rows = len(golden_df)
        aligned_data = [[] for _ in range(num_golden_rows + 1)]

        # Add header row using golden column order
        aligned_data[0] = golden_headers

        # Create empty row template with empty strings
        empty_row = ["" for _ in golden_headers]

        # Create mapping of golden index to matched extracted row
        # Use original values from extracted data
        matches_dict = {}
        for match in matches_info['matched_pairs']:
            original_row = original_extracted_rows[match['extracted_idx']]
            # Create row with values in the same order as golden columns
            ordered_row = []
            for col in golden_headers:
                # If column exists in extracted data, use original value, else empty string
                ordered_row.append(original_row.get(col, ""))
            matches_dict[match['golden_idx']] = ordered_row

        # Fill in the aligned data
        for i in range(num_golden_rows):
            aligned_data[i + 1] = matches_dict.get(i, empty_row.copy())

        return aligned_data

    def log_comparison_report(self, accuracy: float,
                              matches_info: Dict[str, Any]) -> None:
        """Print detailed comparison report."""
        logging.info("\n=== Table Comparison Report ===")

        if matches_info['missing_columns']:
            logging.info("\n🔹 Missing Columns in Extracted Data:")
            for col in matches_info['missing_columns']:
                logging.info(
                    f"⚠️ Column '{col}' not found (counted as mismatch)")

        logging.info("\n🔹 Matched Rows:")
        for pair in matches_info['matched_pairs']:
            logging.info(
                f"✅ Golden Row {pair['golden_idx']} → Extracted Row {pair['extracted_idx']}"
            )
            logging.info(
                f"   Matching Cells: {pair['matching_cells']}/{pair['total_cells']}"
            )
            logging.info(f"   Match Score: {pair['weighted_score']:.2f}")
            if pair.get('key_columns_match'):
                logging.info("   ✨ Key Columns Match")

        if matches_info['unmatched_golden_rows']:
            logging.info("\n🔹 Unmatched Golden Rows:")
            for idx in matches_info['unmatched_golden_rows']:
                logging.info(f"❌ Golden Row {idx} has no match")

        if matches_info['unmatched_extracted_rows']:
            logging.info("\n🔹 Extra Rows in Extracted Data:")
            for idx in matches_info['unmatched_extracted_rows']:
                logging.info(f"⚠️ Extracted Row {idx}")

        logging.info(f"\n🔹 Final Accuracy: {accuracy:.2f}%")
