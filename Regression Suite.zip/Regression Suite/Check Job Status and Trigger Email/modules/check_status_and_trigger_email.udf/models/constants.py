# Constants
API_PROD_BASE_URL = 'https://aihub.instabase.com'
API_UAT_BASE_URL = 'https://aihub-uat.internal.instabase.com'
API_DEV_BASE_URL = 'https://aihub-sandbox.internal.instabase.com'
FLOW_JOB_STATUS_API = '{API_BASE_URL}/api/v1/jobs/status?type=flow&job_id={job_id}'