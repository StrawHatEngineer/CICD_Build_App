import os


def _string_to_bool(text):
    # type: (str) -> bool
    if text.lower() == 'true':
        return True
    return False


class BaseConfig():

    # Email
    USE_AWS_ACCESS_CREDS = os.environ.get('USE_AWS_ACCESS_CREDS', True)
    EMAIL_PROVIDER = os.environ.get('EMAIL_PROVIDER', 'SES').lower()

    SES_ACCESS_KEY_ID = os.environ.get('SES_ACCESS_KEY_ID', '')
    SES_SECRET_ACCESS_KEY = os.environ.get('SES_SECRET_ACCESS_KEY', '')
    SES_REGION_NAME = os.environ.get('SES_REGION_NAME', '')

    SMTP_HOSTNAME = os.environ.get('SMTP_HOSTNAME', 'localhost')
    SMTP_PORT = int(os.environ.get('SMTP_PORT', '25'))

    # AIHUB_APPS_ALERT_NO_REPLY_EMAIL_ADDRESS = 'aihub-apps-alert-noreply@instabase.com'
    NO_REPLY_EMAIL_ADDRESS = os.environ.get('NO_REPLY_EMAIL_ADDRESS',
                                            'no-reply@instabase.com')
