from http.client import HTTPException
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

import requests
import logging
import json

from ..models.request_params import RequestParams


class HttpRequest:

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(HttpRequest, cls).__new__(cls)
            cls._instance.__session = requests.Session()

            retries = Retry(total=5,
                            backoff_factor=5,
                            status_forcelist=[500, 502, 503, 504])
            adapter = HTTPAdapter(max_retries=retries)
            cls._instance.__session.mount("http://", adapter)
            cls._instance.__session.mount("https://", adapter)
        return cls._instance

    def trigger_request(self, method: str, request_params: RequestParams):
        url = request_params.get_url()
        headers = {"Authorization": f"{request_params.get_access_token()}"}
        addn_headers = request_params.get_addn_headers()
        if addn_headers:
            headers.update(addn_headers)

        logging.info('URL triggered: ' + url)
        data = request_params.get_data()
        params = request_params.get_params()

        if len(data) > 0 and isinstance(data, dict):
            data = json.dumps(data)

        # print(headers)
        with self.__session.request(method,
                                    url,
                                    params=params,
                                    headers=headers,
                                    data=data) as response:
            if not 200 <= response.status_code < 300:
                logging.info('Response status code: ' +
                             str(response.status_code))
                self.__session.close()
                raise HTTPException(response)

            self.__session.close()
            return response
