from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from typing import Any, List, Text, Tuple, Union
from mypy_extensions import TypedDict
import boto3


def _create_mime_message(from_addr, to_addr_list, subject, msg_body):
    # type: (Text, List[Text], Text, Text) -> Any
    msg = MIMEMultipart('alternative')  # type: Any
    msg['From'] = u'Instabase <{0}>'.format(from_addr)
    msg['To'] = u",".join(to_addr_list)
    msg['Subject'] = subject

    part1 = MIMEText(msg_body, 'plain')
    part2 = MIMEText(msg_body, 'html')
    msg.attach(part1)
    msg.attach(part2)
    return msg


SESConfigDict = TypedDict(
    'SESConfigDict', {
        'use_aws_access_creds': bool,
        'region_name': Text,
        'ses_access_key_id': Text,
        'ses_secret_access_key': Text
    })

EmailConfigDict = TypedDict('EmailConfigDict', {
    'email_provider': str,
    'from_addr': Text,
    'ses_config': SESConfigDict
})


class EmailClient(object):

    def send_email(self, to_addr, subject, msg_body):
        # type: (List[Text], Text, Text) -> Tuple[bool, Text]
        raise NotImplementedError(u'send_email not implemented')


class SESClient(EmailClient):

    def __init__(self, ses_client, from_addr):
        # type: (Any, Text) -> None
        self._ses_client = ses_client
        self._from_addr = from_addr

    def _send_email(self, to_addr, subject, msg_body):
        # type: (Union[Text, List[Text]], Text, Text) -> Tuple[bool, Text]
        to_addr_list = None  # type: List[Text]
        if not isinstance(to_addr, list):
            to_addr_list = [to_addr]
        else:
            to_addr_list = to_addr

        msg = _create_mime_message(self._from_addr, to_addr_list, subject,
                                   msg_body)

        self._ses_client.send_raw_email(Source=self._from_addr,
                                        Destinations=to_addr_list,
                                        RawMessage={'Data': msg.as_string()})

        return True, None

    def send_email(self, to_addr, subject, msg_body):
        # type: (List[Text], Text, Text) -> Tuple[bool, Text]
        return self._send_email(to_addr, subject, msg_body)


class EmailClientBuilder(object):

    @staticmethod
    def new_client(config):
        # type: (EmailConfigDict) -> Tuple[EmailClient, Text]
        email_provider = config['email_provider']
        if email_provider == 'ses':
            ses_config = config['ses_config']
            if not ses_config:
                return None, u'No SES config provided but email provider is "ses"'

            kwargs = dict(region_name=ses_config['region_name'])
            if ses_config['use_aws_access_creds']:
                kwargs.update(
                    dict(aws_access_key_id=ses_config['ses_access_key_id'],
                         aws_secret_access_key=ses_config[
                             'ses_secret_access_key']))

            ses_client = boto3.client('ses', **kwargs)
            return SESClient(ses_client=ses_client,
                             from_addr=config['from_addr']), None

        return None, u'Unknown email provider: {0}'.format(email_provider)
