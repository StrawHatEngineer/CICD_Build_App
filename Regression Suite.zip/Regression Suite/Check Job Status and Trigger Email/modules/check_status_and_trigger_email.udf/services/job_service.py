import json
import logging
from http.client import HTTPException

from ..models import constants
from ..models.request_params import RequestParams
from .request import HttpRequest


class JobService():

    def __init__(self, access_token, base_url: str):
        self.__http_request = HttpRequest()
        self.__access_token = access_token
        self.__base_url = base_url

    def is_job_done(self, job_id, **kwargs):
        logging.info('Checking the job status: ' + job_id)
        url = constants.FLOW_JOB_STATUS_API.format(API_BASE_URL=self.__base_url,
                                                   job_id=job_id)
        request_params = RequestParams(url=url,
                                       access_token="Bearer " +
                                       self.__access_token)
        response = self.__http_request.trigger_request("GET", request_params)
        response = json.loads(response.content)
        logging.info(
            f"Is {kwargs.get('app_name')} App Test Completed? => {response['status'] != 'OK' or response['state'] == 'DONE'}"
        )
        return response['status'] != 'OK' or response['state'] == 'DONE'
