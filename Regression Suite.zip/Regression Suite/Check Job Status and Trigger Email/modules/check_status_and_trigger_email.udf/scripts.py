from typing import Any
from instabase.provenance.registration import register_fn
import json
import logging
import time
from datetime import datetime
from .services.job_service import *
from .models import constants
from .models.config import BaseConfig
from .services.email_service import *
import urllib.parse
import pandas as pd
import traceback


def __validate_blank(key, val):
    if not val:
        raise Exception(f"{key} is not present in the config")


def __get_date():
    now = datetime.now()
    timestamp = now.strftime("%Y/%m/%d")
    return timestamp


# Get base url based on env, default is UAT env BASE_URL
def __get_base_url(env):
    if env.upper() == 'PROD':
        return constants.API_PROD_BASE_URL
    elif env.upper() == 'UAT':
        return constants.API_UAT_BASE_URL
    elif env.upper() == 'DEV':
        return constants.API_DEV_BASE_URL

    return constants.API_UAT_BASE_URL


def __get_email_data(app_names, tests_summary_dict, base_url):
    data = {
        'S.No': [],
        'App Name': [],
        'App UUID': [],
        'Test Status': [],
        'Summary Link': [],
        'Total Fields': [],
        'Automation Rate Impacted Fields': [],
        'Validated Accuracy Impacted Fields': [],
        'Note': []
    }
    for i, app_name in enumerate(app_names):
        data['S.No'].append(i + 1)
        data['App Name'].append(app_name)

        summary_dict = tests_summary_dict.get(app_name, dict())
        data['App UUID'].append(summary_dict.get('App_UUID', ''))

        summary_link = ''
        if summary_dict.get('Summary_Path'):
            summary_link = urllib.parse.quote(base_url + '/' +
                                              summary_dict['Summary_Path'],
                                              safe='/:?=&')

        if 'Test_Status' in summary_dict:
            test_status = summary_dict['Test_Status']

            accuracies = {}
            for key, val in summary_dict.items():
                if isinstance(
                        val, dict
                ) and 'automation' in val and 'automation_accuracy' in val:
                    accuracies = val
                    break

            data['Test Status'].append(test_status)
            data['Summary Link'].append(
                f'<a href="{summary_link}">link</a>' if summary_link else '')
            data['Total Fields'].append(
                accuracies.get('automation_accuracy',
                               {}).get('Total_Fields', ''))
            data['Automation Rate Impacted Fields'].append(
                accuracies.get('automation',
                               {}).get('Accuracy_Drop_Above_Threshold_Count',
                                       ''))
            data['Validated Accuracy Impacted Fields'].append(
                accuracies.get('automation_accuracy',
                               {}).get('Accuracy_Drop_Above_Threshold_Count',
                                       ''))
            data['Note'].append(summary_dict.get("Note", ""))

        elif summary_dict and len(summary_dict) > 0:
            data['Test Status'].append('Failed')
            data['Summary Link'].append(
                f'<a href="{summary_link}">link</a>' if summary_link else '')
            data['Total Fields'].append('')
            data['Automation Rate Impacted Fields'].append('')
            data['Validated Accuracy Impacted Fields'].append('')
            data['Note'].append(
                summary_dict.get("Note")
            )  # ('An issue occurred while executing Regression Test Runner flow')
        else:
            data['Test Status'].append('Failed')
            data['Summary Link'].append(
                f'<a href="{summary_link}">link</a>' if summary_link else '')
            data['Total Fields'].append('')
            data['Automation Rate Impacted Fields'].append('')
            data['Validated Accuracy Impacted Fields'].append('')
            data['Note'].append(
                summary_dict.get(
                    "Note",
                    "An issue occurred while executing Regression Test Runner flow. Unable to monitor the status of Application Run, Flow exited abnormally."
                ))

    return data


def __trigger_email(app_names, tests_summary_dict, ALERT_EMAIL_ID, base_url):
    table_data = __get_email_data(app_names, tests_summary_dict, base_url)
    # Creating email body and sending summary for all apps

    # email_body = "<ul>"
    # for app_name in app_names:
    #   summary_dict = tests_summary_dict.get(app_name, dict())
    #   email_body += f"<li><b>{app_name} Test Status</b>: "
    #   if 'TestStatus' in summary_dict:
    #     test_status = summary_dict['TestStatus']
    #     summary_link = urllib.parse.quote(base_url + '/' + summary_dict['SummaryPath'], safe='/:?=&')
    #     summary = f"test summary can be found <a href={summary_link}>here</a>"
    #     if test_status != 'Passed':
    #       email_body += f"<b>{test_status}</b>, {summary}</li>"
    #     else:
    #       email_body += f"{test_status}, {summary}</li>"
    #   elif summary_dict and len(summary_dict) > 0:
    #     email_body += f"<b>Failed</b>, an issue occurred while executing Regression Test Runner flow</li>"
    #   else:
    #     email_body += f"<b>Failed</b>, Unable to trigger regression test runner</li>"
    # email_body += "</ul>"

    df = pd.DataFrame(table_data)
    table_html = df.to_html(index=False, border=1, classes='table')
    table_html = table_html.replace(
        '<table', '<table style="border-collapse: collapse;"').replace(
            '<tr style="text-align: right;">',
            '<tr style="text-align:center; padding: 5px; font-weight:bold"'
        ).replace('<th>', '<th style="padding: 5px;">').replace(
            '<td>', '<td style="text-align: center; padding: 5px">').replace(
                '&lt;', '<').replace('&gt;', '>')
    # table_html = table_html.replace('<td>https://', '<td><a href="https://').replace('</td>', '">link</a></td>')
    # print(table_html)

    email_body = f"""
  <html>
    <body>
      <p>Please find below the summary of application tests:</p>
      {table_html}
      <p>For more details, you can click on the summary links provided.</p>
    </body>
  </html>
  """

    failedAppsCount = table_data['Test Status'].count('Failed')
    totalApps = len(app_names)
    overallTestStatus = 'Failed' if failedAppsCount > 0 else 'Success'
    failedCountIndicator = f'({failedAppsCount}/{totalApps})' if failedAppsCount > 0 else ''

    app_config = BaseConfig()
    email_config = EmailConfigDict(
        email_provider=app_config.EMAIL_PROVIDER,
        from_addr=app_config.NO_REPLY_EMAIL_ADDRESS,
        ses_config=SESConfigDict(
            use_aws_access_creds=app_config.USE_AWS_ACCESS_CREDS,
            region_name=app_config.SES_REGION_NAME,
            ses_access_key_id=app_config.SES_ACCESS_KEY_ID,
            ses_secret_access_key=app_config.SES_SECRET_ACCESS_KEY))
    email_client, email_err = EmailClientBuilder.new_client(email_config)
    if email_err:
        raise Exception(email_err)
    date_val = __get_date()
    email_client.send_email(
        to_addr=ALERT_EMAIL_ID,
        subject=
        f'{overallTestStatus} {failedCountIndicator} - AIHub-UAT Marketplace Apps Regression Suite Summary ({date_val})',
        msg_body=email_body)
    logging.info('Triggered summary email')


@register_fn(provenance=False)
def check_job_status_and_trigger_email(clients, *args: Any,
                                       **kwargs: Any) -> None:
    try:
        fn_context = kwargs.get('_FN_CONTEXT_KEY')
        config, err = fn_context.get_by_col_name('CONFIG')

        # Get token to trigger the job api
        AUTH_TOKEN = config['TOKEN']

        # get the app names and job ids
        jobs_triggered = config['JOBS_TRIGGERED']
        if (len(jobs_triggered) == 0):
            return

        # get the email id to trigger
        ALERT_EMAIL_ID = config.get('ALERT_EMAIL_ID',
                                    'aihub-apps-alert@instabase.com')

        # get the tests summary json path
        TESTS_SUMMARY_PATH = config['TESTS_SUMMARY_PATH']

        # Get the env of AI Hub
        ENV = config.get('ENV', 'UAT')

        # check for blank value
        __validate_blank("TOKEN", AUTH_TOKEN)
        __validate_blank("TESTS_SUMMARY_PATH", TESTS_SUMMARY_PATH)

        base_url = __get_base_url(ENV)
        job_service = JobService(AUTH_TOKEN, base_url)

        for app_name, job_id in jobs_triggered.items():
            if job_id:
                while not job_service.is_job_done(job_id, app_name=app_name):
                    time.sleep(60)

        time.sleep(60)
        try:
            tests_summary_dict = json.loads(
                clients.ibfile.read_file(TESTS_SUMMARY_PATH)[0])
        except:
            tests_summary_dict = {}

        __trigger_email(list(jobs_triggered.keys()), tests_summary_dict,
                        ALERT_EMAIL_ID, base_url)
    except:
        logging.error(
            f"Exception occurred in check_job_status_and_trigger_email")
        logging.error(f"{traceback.format_exc()}")
