## Objective
  - Checks the status of each job Id provided for each application through polls. 
  - When all jobs are finished, it gathers the test summaries and sends an email.

## Input
  -  Dummy single file input folder [ib_app_admin/regression_test_setup/fs/Instabase Drive/flows/Regression Test Runner/datasets/in]

## Runtime Config

```
{
 "JOBS_TRIGGERED": "{app_name_job_id_map}"
 "TOKEN": "{ib_app_admin_token}",
 "TESTS_SUMMARY_PATH": "{tests_summary_path}"
 "ALERT_EMAIL_ID": "aihub-apps-alert@instabase.com"
}
```

## Note
- TESTS_SUMMARY_PATH is the file where all apps write their summary. This gets initially created in the trigger_flow flow and 
  later passes it to subsequent flows. E.g: ib_app_admin/regression_test_setup/fs/Instabase Drive/files/2024/01/31/test_summary_20240131034808.json
- Solution Comparison doesnot work if flow contains split-classifier
- To add new application for running regression tests, create a config like other applications e.g:[ib_app_admin/regression_test_setup/fs/Instabase Drive/configs/car_title_config.json] 
and add it in main_config.json [ib_app_admin/regression_test_setup/fs/Instabase Drive/configs/main_config.json] with application name as the key (same name which is used for deployment)
- Whenever a new version of an application is deployed, update the 'GOLDEN_METRIC_PATH' in the application's configuration with the most recent metrics generated path for that specific version of the application.
- This is currently configured only in AI Hub UAT environment
- Example for app_name_job_id_map - {"passport": "12d78d34-824a-4ff1-8573-6b6645c26be5", "Car Title": "8b5f6366-7a24-49bc-9d72-0953f82a962f", ....}