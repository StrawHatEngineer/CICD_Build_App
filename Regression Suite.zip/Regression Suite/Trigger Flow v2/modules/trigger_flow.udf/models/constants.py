# Constants
API_PROD_BASE_URL = 'https://aihub.instabase.com'
API_UAT_BASE_URL = 'https://aihub-uat.internal.instabase.com'
API_DEV_BASE_URL = 'https://aihub-sandbox.internal.instabase.com'
APP_RUN_API = '{API_BASE_URL}/api/v2/zero-shot-idp/projects/app/run'
FLOW_JOB_STATUS_API = '{API_BASE_URL}/api/v1/jobs/status?type=flow&job_id={job_id}'
RESULTS_API = '{API_BASE_URL}/api/v1/flow_binary/results'
FILE_SERVICE_API = '{API_BASE_URL}/api/v2/files'

FLOW_API = "{API_BASE_URL}/api/v1/flow/run_flow_async"
