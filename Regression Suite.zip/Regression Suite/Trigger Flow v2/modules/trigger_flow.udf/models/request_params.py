from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry


class RequestParams:

    def __init__(
        self,
        url: str,
        access_token: str,
        addn_headers: dict = {},
        params: dict = {},
        data: dict = {},
        **kwargs: object,
    ) -> None:
        self.__url = url
        self.__access_token = access_token
        self.__addn_headers = addn_headers
        self.__params = params
        self.__data = data

    def get_url(self):
        return self.__url

    def get_access_token(self):
        return self.__access_token

    def get_addn_headers(self):
        return self.__addn_headers

    def get_params(self):
        return self.__params

    def get_data(self):
        return self.__data
