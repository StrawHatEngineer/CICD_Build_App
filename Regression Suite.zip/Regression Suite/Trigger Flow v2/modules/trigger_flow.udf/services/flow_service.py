import json
import logging
from http.client import HTTPException

from ..models import constants
from ..models.request_params import RequestParams
from .request import HttpRequest

API_STATUS_OK = "OK"
API_STATUS_ERROR = "ERROR"


class FlowService():

    def __init__(self, access_token, base_url: str):
        self.__http_request = HttpRequest()
        self.__access_token = access_token
        self.__base_url = base_url

    def trigger_flow_async(self,
                           flow_path,
                           config,
                           input_files_path,
                           tags=[],
                           pipeline_ids=[]):
        try:
            flow_url = url = constants.FLOW_API.format(
                API_BASE_URL=self.__base_url)
            data = {
                "ibflow_path": flow_path,
                "input_dir": input_files_path,
                "compile_and_run_as_binary": True,
                "output_has_run_id": True,
                "delete_out_dir": False,
                "log_to_timeline": True,
                "disable_step_timeout": False,
                "step_timeout": -1,
                "enable_ibdoc": True,
                "compare_against_golden_set": False,
                "tags": tags,
                "pipeline_ids": pipeline_ids,
                # "pipeline_ids": [],
                "webhook_config": {
                    "headers": {}
                },
                "runtime_config": config
            }
            request_params = RequestParams(url=flow_url,
                                           access_token="Bearer " +
                                           self.__access_token,
                                           data=data)
            res = self.__http_request.trigger_request("post", request_params)

            if res.json()["status"] == API_STATUS_OK:
                logging.info(
                    'Triggered regression test runner flow successfully')
                return res.json()["data"]["job_id"]

            if res.json()["status"] == API_STATUS_ERROR:
                if 'msg' in res.json():
                    logging.error(
                        'Post flow failure: Unable to trigger the regression test runner flow, msg: '
                        + res.json()['msg'])
                else:
                    logging.info(
                        'Post flow failure: Unable to trigger the regression test runner flow'
                    )
                return ''

            return ''
        except Exception as ex:
            logging.error(ex)
            return ''
