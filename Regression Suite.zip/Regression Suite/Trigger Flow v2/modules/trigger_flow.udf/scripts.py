from typing import Any
from instabase.provenance.registration import register_fn
import json
import logging
import time
import traceback
from datetime import datetime
from .services.flow_service import *
from .models import constants
from .models.config import BaseConfig
from .services.email_service import *


def __validate_blank(key, val):
    if not val:
        raise Exception(f"{key} is not present in the config")


def __get_date():
    now = datetime.now()
    timestamp = now.strftime("%Y/%m/%d")
    return timestamp


# Get base url based on env, default is UAT env BASE_URL
def __get_base_url(env):
    if env.upper() == 'PROD':
        return constants.API_PROD_BASE_URL
    elif env.upper() == 'UAT':
        return constants.API_UAT_BASE_URL
    elif env.upper() == 'DEV':
        return constants.API_DEV_BASE_URL

    return constants.API_UAT_BASE_URL


def __trigger_test_runner_flow(config, flow_service, FLOW_PATH,
                               DUMMY_FOLDER_PATH):
    try:
        app_name = config["APP_NAME"]
        job_id = flow_service.trigger_flow_async(FLOW_PATH,
                                                 config,
                                                 DUMMY_FOLDER_PATH,
                                                 tags=[
                                                     f'{app_name}', "SOL_ENG",
                                                     "REGRESSION", "TEST_SUITE",
                                                     "APP_TRIGGER"
                                                 ])
        logging.info('Regression test runner job_id: ' + job_id +
                     ' for app_name: ' + app_name)
        return job_id
    except Exception as ex:
        logging.error(
            f"Exception occurred while triggering App: {app_name} Specific Regression Test"
        )
        logging.error(traceback.format_exc())
        return None


def __trigger_check_status_and_trigger_email_flow(config, flow_service,
                                                  FLOW_PATH, DUMMY_FOLDER_PATH):
    try:
        job_id = flow_service.trigger_flow_async(
            FLOW_PATH,
            config,
            DUMMY_FOLDER_PATH,
            tags=["SOL_ENG", "REGRESSION", "TEST_SUITE", "EMAIL_TRIGGER"])
        logging.info('trigger check status and trigger email flow, job_id: ' +
                     job_id)
        return job_id
    except Exception as ex:
        logging.error(f"Exception occurred while triggering email flow")
        logging.error(traceback.format_exc())
        return None


@register_fn(provenance=False)
def trigger_flow(clients, *args: Any, **kwargs: Any) -> None:
    try:
        fn_context = kwargs.get('_FN_CONTEXT_KEY')
        config, err = fn_context.get_by_col_name('CONFIG')

        # Get application information from the main config file (application name and application config file path)
        config_file = config['MAIN_CONFIG_FILE']

        # Get token to trigger the flow api
        AUTH_TOKEN = config['TOKEN']

        # Get the flow path of Regression Test Runner
        FLOW_PATH = config['FLOW_PATH']

        # Get the input folder for triggering the flow
        DUMMY_FOLDER_PATH = config['DUMMY_FOLDER_PATH']
        ALERT_EMAIL_ID = config['ALERT_EMAIL_ID']
        TESTS_SUMMARY_PATH = config.get(
            'TESTS_SUMMARY_PATH',
            'ib-internal/SolEng_workspace/fs/Instabase Drive/files')
        if TESTS_SUMMARY_PATH[-1] != '/':
            TESTS_SUMMARY_PATH += '/'
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        TESTS_SUMMARY_PATH += (__get_date() + f'/test_summary_{timestamp}.json')
        clients.ibfile.write_file(TESTS_SUMMARY_PATH, json.dumps({}))
        config['TESTS_SUMMARY_PATH'] = TESTS_SUMMARY_PATH

        # get status check and email trigger flow
        #"ib_app_admin/regression_test_setup/fs/Instabase Drive/flows/Check Job Status and Trigger Email/check_job_status_and_trigger_email.ibflow"
        CHECK_STATUS_EMAIL_TRIGGER_FLOW = config[
            'CHECK_STATUS_EMAIL_TRIGGER_FLOW']

        # Get the env of AI Hub
        ENV = config.get('ENV', 'UAT')

        # check for blank value
        __validate_blank("MAIN_CONFIG_FILE", config_file)
        __validate_blank("TOKEN", AUTH_TOKEN)
        __validate_blank("FLOW_PATH", FLOW_PATH)
        __validate_blank("ALERT_EMAIL_ID", ALERT_EMAIL_ID)
        __validate_blank("DUMMY_FOLDER_PATH", DUMMY_FOLDER_PATH)
        __validate_blank("CHECK_STATUS_EMAIL_TRIGGER_FLOW",
                         CHECK_STATUS_EMAIL_TRIGGER_FLOW)

        if not clients.ibfile.exists(config_file):
            raise Exception(f"{config_file} is not a valid path")

        config_file = json.loads(clients.ibfile.read_file(config_file)[0])
        base_url = __get_base_url(ENV)

        # For each app mentioned in the config triggering the Regression Test Runner flow.
        flow_service = FlowService(AUTH_TOKEN, base_url)
        jobs_triggered = dict()
        total_apps = len(config_file)
        for i, (app_name,
                app_config_file_path) in enumerate(config_file.items()):
            config["APP_NAME"] = app_name
            config["APP_CONFIG_FILE"] = app_config_file_path

            job_id = __trigger_test_runner_flow(config, flow_service, FLOW_PATH,
                                                DUMMY_FOLDER_PATH)
            jobs_triggered[app_name] = job_id
            if not job_id:
                if not clients.ibfile.exists(app_config_file_path):
                    logging.info(f"Config file missing for {app_name}")
                    continue

                app_config_file = json.loads(
                    clients.ibfile.read_file(app_config_file_path)[0])
                if not app_config_file:
                    logging.info(f"Config file missing for {app_name}")
                    continue

            if i < total_apps - 1:
                # Waiting for 3 mins before triggering the flow for next app
                time.sleep(60 * 3)

        config["JOBS_TRIGGERED"] = jobs_triggered
        __trigger_check_status_and_trigger_email_flow(
            config, flow_service, CHECK_STATUS_EMAIL_TRIGGER_FLOW,
            DUMMY_FOLDER_PATH)
    except:
        logging.error(f"Exception occurred in trigger_flow")
        logging.error(traceback.format_exc())
